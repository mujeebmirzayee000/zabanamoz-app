﻿class SupabaseConfig {n  static const String url = 'https://jgkxhnsaunqbylfvlfwh.supabase.co';n  static const String anonKey = 'Sb_publishable_mPINybrSIiFdFzNxLROS5Q_JxK8Nga_';
}
