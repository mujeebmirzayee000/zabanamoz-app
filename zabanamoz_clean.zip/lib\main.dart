);
  }
}

class VideosScreen extends StatelessWidget {
  const VideosScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ویدیوهای آموزشی')),
      body: const Center(
        child: Text(
          'پخش‌کننده ویدیوهای آموزشی',
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('پیشرفت من')),
      body: const Center(
        child: Text(
          'درصد پیشرفت در دوره‌ها و نمرات آزمون‌ها',
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('پروفایل کاربری')),
      body: const Center(
        child: Text(
          'مدیریت حساب کاربری و تنظیمات',
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}