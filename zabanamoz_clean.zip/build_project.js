
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('پروفایل کاربری')),
      body: const Center(child: Text('تنظیمات پروفایل و خروج')),
    );
  }
}
,

  // 3. Admin Web Panel
  'admin-panel/package.json': {
  "name": "zabanamoz-admin-panel",
  "private": true,
  "version": "1.0.0",
  "scripts": { "dev": "vite", "build": "vite build" },
  "dependencies": {
    "@supabase/supabase-js": "^2.45.0",
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  }
}
,

  'admin-panel/.env': VITE_SUPABASE_URL=https://jgkxhnsaunqbylfvlfwh.supabase.co
VITE_SUPABASE_ANON_KEY=Sb_publishable_mPINybrSIiFdFzNxLROS5Q_JxK8Nga_
,

  'admin-panel/src/App.jsx': import React from 'react';

export default function AdminApp() {
  return (
    <div style={{ padding: '30px', background: '#0A192F', color: '#fff', minHeight: '100vh', fontFamily: 'sans-serif' }}>
      <h1>پنل ادمین فوق امنیتی - Zabanamoz</h1>
      <p>مدیریت دوره‌ها، درس‌ها، گرامر، کاربران و لاگ‌های امنیتی</p>
    </div>
  );
}

};

for (const [filePath, content] of Object.entries(files)) {
  const fullPath = path.join(__dirname, filePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, content.trim(), 'utf8');
  console.log('Created: ' + filePath);
}
console.log('\\n>>> All files and project structure created successfully! <<<');