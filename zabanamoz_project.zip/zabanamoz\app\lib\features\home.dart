import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../core/constants.dart';
import '../core/supabase_client.dart';
import '../core/widgets.dart';
import '../data/models.dart';
import '../data/repos.dart';

/// صفحه خانه: خوش‌آمد + پیشرفت کاربر + جستجو + دوره‌های منتخب
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Course>? _courses;
  List<UserProgress>? _progress;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({bool refresh = false}) async {
    try {
      final courses = await Repos.fetchCourses(refresh: refresh);
      List<UserProgress> progress = [];
      try {
        progress = await Repos.fetchProgress();
      } catch (_) {}
      if (mounted) {
        setState(() {
          _courses = courses;
          _progress = progress;
          _error = '';
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = 'اتصال برقرار نشد. دوباره تلاش کنید.');
    }
  }

  int get _completedCount =>
      _progress?.where((p) => p.completed).length ?? 0;

  @override
  Widget build(BuildContext context) {
    final user = sb.auth.currentUser;
    final name = user?.userMetadata?['full_name'] as String?;
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(AppConstants.appName),
        actions: [
          IconButton(
            tooltip: 'جستجو',
            icon: const Icon(Icons.search_rounded),
            onPressed: () => context.go('/search'),
          ),
        ],
      ),
      body: _error.isNotEmpty
          ? ErrorView(message: _error, onRetry: () => _load(refresh: true))
          : _courses == null
              ? const LoadingView()
              : RefreshIndicator(
                  onRefresh: () => _load(refresh: true),
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'سلام ${name ?? 'دوست عزیز'} 👋',
                                style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 4),
                              Text(AppConstants.appTagline, style: theme.textTheme.bodyMedium),
                              const SizedBox(height: 16),
                              Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'پیشرفت شما: $_completedCount درس تکمیل‌شده',
                                          style: theme.textTheme.bodyMedium,
                                        ),
                                        const SizedBox(height: 8),
                                        LinearProgressIndicator(
                                          value: (_courses?.isNotEmpty ?? false)
                                              ? (_completedCount / (_progress?.length ?? 1)).clamp(0.0, 1.0)
                                              : 0,
                                          minHeight: 8,
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  FilledButton.tonal(
                                    onPressed: () => context.go('/progress'),
                                    child: const Text('جزئیات'),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      SectionTitle('دوره‌ها', action: TextButton(
                        onPressed: () => context.go('/courses'),
                        child: const Text('مشاهده همه'),
                      )),
                      if (_courses!.isEmpty)
                        const EmptyView(message: 'هنوز دوره‌ای منتشر نشده است.'),
                      for (final c in _courses!)
                        Card(
                          child: ListTile(
                            leading: CircleAvatar(
                              child: Text(c.levelName.substring(0, 1)),
                            ),
                            title: Text(c.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Text(
                              c.description,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: const Icon(Icons.chevron_left),
                            onTap: () => context.go('/courses/${c.id}'),
                          ),
                        ),
                      const SizedBox(height: 8),
                      SectionTitle('دسترسی سریع'),
                      Row(
                        children: [
                          Expanded(
                            child: _QuickCard(
                              icon: Icons.rule_rounded,
                              label: 'گرامر',
                              onTap: () => context.go('/grammar'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _QuickCard(
                              icon: Icons.play_circle_rounded,
                              label: 'ویدیوها',
                              onTap: () => context.go('/videos'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
    );
  }
}

class _QuickCard extends StatelessWidget {
  const _QuickCard({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Icon(icon, size: 40, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 8),
              Text(label),
            ],
          ),
        ),
      ),
    );
  }
}
