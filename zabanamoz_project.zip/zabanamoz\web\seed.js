/* ============================================================
   زبان‌آموز — کتابخانه محتوای آموزشی (نسخه ۱)
   محتوای اولیه دوره‌ها، درس‌ها، گرامر، تمرین شنیداری و واژه‌ها
   ============================================================ */
window.ZA_SEED = (function () {
  'use strict';

  function mk(prefix, n, width) {
    var tail = String(n);
    while (tail.length < (width || 12)) tail = '0' + tail;
    return prefix + '-0000-4000-8000-' + tail;
  }

  var courses = [
    {
      n: 1,
      title: 'انگلیسی از صفر',
      description: 'از الفبا تا جمله‌سازی روزمره؛ مناسب کسانی که تازه شروع کرده‌اند.',
      level: 1,
      color: 'blue',
      lessons: [
        {
          title: 'الفبا و صداها',
          content: [
            '## الفبای انگلیسی',
            'انگلیسی ۲۶ حرف دارد. حروف بزرگ (A B C) و کوچک (a b c) شکل متفاوت دارند اما صدای یکسانی می‌دهند. برای شروع، اسم حروف را یاد بگیر و بعد سراغ صداها برو.',
            '### حروف صدادار و بی‌صدا',
            '- حروف صدادار: **A, E, I, O, U** (و گاهی Y).',
            '- بقیه حروف بی‌صدا هستند.',
            '- هر کلمه انگلیسی حداقل یک صدای صدادار دارد؛ بدون آن کلمه تلفظ نمی‌شود.',
            '### سه صدای مهم برای فارسی‌زبان‌ها',
            '- **th**: زبان را بین دندان‌ها بگذار. think /θɪŋk/، this /ðɪs/',
            '- **w** و **v** را اشتباه نگیر: west /west/ در برابر vest /vest/',
            '- **p** را با دمیدن هوا بگو: pen، apple',
            '### تمرین',
            'کلمه‌های زیر را بلند بخوان و صدای اول هر کدام را مشخص کن: book, apple, table, English, water.',
            '> نکته: تلفظ درست از حفظ کردن قواعد مهم‌تر است. روزی ۱۰ دقیقه بلند خواندن، تفاوت بزرگی می‌سازد.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'alphabet', fa: 'الفبا', ipa: '/ˈæl.fə.bet/' },
            { en: 'vowel', fa: 'حرف صدادار', ipa: '/ˈvaʊ.əl/' },
            { en: 'sound', fa: 'صدا', ipa: '/saʊnd/' },
            { en: 'letter', fa: 'حرف', ipa: '/ˈlet.ər/' }
          ],
          quiz: [
            { q: 'کدام حرف صدادار نیست؟', options: ['A', 'E', 'B', 'O'], answer: 2, why: 'B یک حرف بی‌صدا است؛ حروف صدادار A, E, I, O, U هستند.' },
            { q: 'در کلمه «think» کدام صدا وجود دارد؟', options: ['/s/', '/θ/', '/tʃ/', '/z/'], answer: 1, why: 'حروف th در think صدای /θ/ می‌دهد.' },
            { q: 'کدام کلمه با صدای /v/ شروع می‌شود؟', options: ['west', 'vest', 'best', 'rest'], answer: 1, why: 'vest با /v/ و west با /w/ شروع می‌شود.' }
          ]
        },
        {
          title: 'سلام و احوال‌پرسی',
          content: [
            '## شروع یک گفت‌وگو',
            'در انگلیسی بسته به زمان روز و میزان رسمی‌بودن رابطه، سلام‌های مختلفی داریم.',
            '### سلام‌های رایج',
            '- **Good morning** صبح تا ظهر',
            '- **Good afternoon** بعدازظهر',
            '- **Good evening** عصر و شب (هنگام ورود)',
            '- **Hello / Hi** دوستانه و عمومی',
            '### پرسیدن حال',
            '- How are you? — چطوری؟',
            '- How are you doing? — اوضاع چطوره؟ (دوستانه)',
            '- How is it going? — چه خبر؟ (غیررسمی)',
            'پاسخ‌های طبیعی: I am fine, thanks. / Pretty good. / Not bad.',
            '### معرفی خود',
            '- My name is Sara. — اسم من ساراست.',
            '- I am from Afghanistan. — من اهل افغانستان هستم.',
            '- Nice to meet you. — از آشنایی با شما خوشحالم.',
            '> نکته فرهنگی: در انگلیسی معمولاً از «شما» و «تو» جدا استفاده نمی‌شود؛ لحن و انتخاب کلمات رسمیت را مشخص می‌کند.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'greeting', fa: 'سلام و احوال‌پرسی', ipa: '/ˈɡriː.tɪŋ/' },
            { en: 'fine', fa: 'خوب', ipa: '/faɪn/' },
            { en: 'introduce', fa: 'معرفی کردن', ipa: '/ˌɪn.trəˈdjuːs/' },
            { en: 'nice to meet you', fa: 'از آشنایی خوشحالم', ipa: '/naɪs tə miːt juː/' }
          ],
          quiz: [
            { q: '«My name is Ali» یعنی چه؟', options: ['من علی هستم', 'اسم من علی است', 'علی کجاست؟', 'اسم تو چیست؟'], answer: 1, why: 'My name is … یعنی «اسم من … است».' },
            { q: 'کدام پاسخ برای How are you? طبیعی است؟', options: ['I am twelve.', 'I am fine, thanks.', 'It is a book.', 'Yes, please.'], answer: 1, why: 'پاسخ حال‌پرسی با I am fine, thanks رایج است.' },
            { q: 'کدام جمله برای معرفی خود درست است؟', options: ['I from Herat am.', 'I am from Herat.', 'Me from Herat.', 'My from Herat.'], answer: 1, why: 'ساختار درست: فاعل + am/is/are + from + مکان.' }
          ]
        },
        {
          title: 'فعل to be (am / is / are)',
          content: [
            '## مهم‌ترین فعل انگلیسی',
            'فعل to be به معنی «بودن» است و در فارسی معمولاً در جمله نمی‌آید، اما در انگلیسی حتماً باید بیاید.',
            '### صرف در حال ساده',
            '- I **am** — من هستم',
            '- You **are** — تو/شما هستید',
            '- He / She / It **is** — او است',
            '- We **are** — ما هستیم',
            '- They **are** — آن‌ها هستند',
            '### منفی و سؤالی',
            '- I am not tired. — خسته نیستم.',
            '- She is not (isn’t) a doctor. — او دکتر نیست.',
            '- Are you ready? — آماده‌ای؟',
            '- Is he at home? — او خانه است؟',
            '### اشتباه رایج فارسی‌زبانان',
            'حذف am/is/are: ❌ I tired. ✅ **I am tired.**',
            '> قاعده طلایی: در انگلیسی هر جمله باید فعل داشته باشد؛ اگر فعل اصلی نیست، از to be استفاده کن.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'be', fa: 'بودن', ipa: '/biː/' },
            { en: 'tired', fa: 'خسته', ipa: '/ˈtaɪ.əd/' },
            { en: 'ready', fa: 'آماده', ipa: '/ˈred.i/' },
            { en: 'doctor', fa: 'دکتر', ipa: '/ˈdɒk.tər/' }
          ],
          quiz: [
            { q: 'جای خالی: She ___ a teacher.', options: ['am', 'is', 'are', 'be'], answer: 1, why: 'برای he/she/it از is استفاده می‌شود.' },
            { q: 'کدام جمله درست است؟', options: ['They is happy.', 'They are happy.', 'They am happy.', 'They be happy.'], answer: 1, why: 'برای they از are استفاده می‌شود.' },
            { q: 'منفی کردن «I am busy» کدام است؟', options: ['I not busy.', 'I am not busy.', 'I don’t busy.', 'I amn’t busy.'], answer: 1, why: 'منفی to be با افزودن not بعد از am/is/are ساخته می‌شود.' }
          ]
        },
        {
          title: 'اعداد، ساعت و تاریخ',
          content: [
            '## اعداد پایه',
            '1 one، 2 two، 3 three، 4 four، 5 five، 6 six، 7 seven، 8 eight، 9 nine، 10 ten.',
            '11 eleven، 12 twelve، 13 thirteen، 14 fourteen، 15 fifteen، 16 sixteen، 17 seventeen، 18 eighteen، 19 nineteen، 20 twenty.',
            '### دهگان‌ها',
            '30 thirty، 40 forty، 50 fifty، 60 sixty، 70 seventy، 80 eighty، 90 ninety، 100 one hundred.',
            '### پرسیدن ساعت',
            '- What time is it? — ساعت چند است؟',
            '- It is **seven o’clock**. — ساعت هفت است.',
            '- It is **half past seven**. — هفت و نیم.',
            '- It is **quarter to eight**. — یک‌ربع به هشت.',
            '### تاریخ',
            'در انگلیسی بریتانیایی می‌گوییم: the fifth of May. در آمریکایی: May fifth.',
            '> تمرین: ساعت ۸:۴۵ را به دو شکل بگو (quarter to nine / eight forty-five).'
          ].join('\n\n'),
          vocabulary: [
            { en: 'number', fa: 'عدد', ipa: '/ˈnʌm.bər/' },
            { en: 'o’clock', fa: 'ساعتِ کامل', ipa: '/əˈklɒk/' },
            { en: 'half past', fa: 'نیم ساعت بعد از', ipa: '/hɑːf pɑːst/' },
            { en: 'date', fa: 'تاریخ', ipa: '/deɪt/' }
          ],
          quiz: [
            { q: '«هفت و نیم» کدام است؟', options: ['half past six', 'half past seven', 'quarter past seven', 'seven to half'], answer: 1, why: 'half past seven یعنی نیم ساعت بعد از هفت.' },
            { q: 'عدد ۴۰ کدام است؟', options: ['fourteen', 'forty', 'fourty', 'four'], answer: 1, why: 'نوشتار درست forty است (بدون u).' },
            { q: '«quarter to eight» یعنی چه؟', options: ['هشت و ربع', 'یک‌ربع به هشت', 'نیم ساعت به هشت', 'هشت دقیقه'], answer: 1, why: 'quarter to eight یعنی ۷:۴۵.' }
          ]
        },
        {
          title: 'خانواده و روابط',
          content: [
            '## اعضای خانواده',
            '- father / mother — پدر / مادر',
            '- brother / sister — برادر / خواهر',
            '- son / daughter — پسر / دختر (فرزند)',
            '- husband / wife — شوهر / همسر',
            '- grandfather / grandmother — پدربزرگ / مادربزرگ',
            '### مالکیت',
            'با اضافه کردن **’s** مالکیت را نشان می‌دهیم:',
            '- This is **my father’s** car. — این ماشین پدرم است.',
            '- Sara is **Ali’s** sister. — سارا خواهر علی است.',
            '### توصیف افراد',
            '- My brother is tall and funny. — برادرم قدبلند و بامزه است.',
            '- She has two children. — او دو فرزند دارد.',
            '> توجه: برای اعضای نزدیک خانواده معمولاً از my بدون a/the استفاده می‌کنیم: my mother (نه the my mother).'
          ].join('\n\n'),
          vocabulary: [
            { en: 'family', fa: 'خانواده', ipa: '/ˈfæm.əl.i/' },
            { en: 'brother', fa: 'برادر', ipa: '/ˈbrʌð.ər/' },
            { en: 'daughter', fa: 'دختر', ipa: '/ˈdɔː.tər/' },
            { en: 'children', fa: 'فرزندان', ipa: '/ˈtʃɪl.drən/' }
          ],
          quiz: [
            { q: '«ماشین پدرم» کدام است؟', options: ['my father car', 'my father’s car', 'car my father', 'the my father car'], answer: 1, why: 'برای مالکیت از ’s استفاده می‌شود.' },
            { q: 'جمع child چیست؟', options: ['childs', 'children', 'childes', 'childrens'], answer: 1, why: 'child جمع بی‌قاعده دارد: children.' },
            { q: '«او دو خواهر دارد» کدام است؟', options: ['She have two sisters.', 'She has two sisters.', 'She is two sisters.', 'She has two sister.'], answer: 1, why: 'برای سوم‌شخص مفرد از has استفاده می‌شود.' }
          ]
        },
        {
          title: 'زندگی روزمره و حال ساده',
          content: [
            '## حال ساده برای عادت‌ها',
            'زمان حال ساده برای کارهای تکرارشونده، عادت‌ها و حقایق به کار می‌رود.',
            '### ساختار',
            'فاعل + فعل؛ برای he/she/it به فعل **s** اضافه می‌شود.',
            '- I **wake up** at 6. — ساعت ۶ بیدار می‌شوم.',
            '- She **works** in a hospital. — او در بیمارستان کار می‌کند.',
            '### قیدهای تکرار',
            '- always همیشه، usually معمولاً، often اغلب، sometimes گاهی، never هرگز.',
            '- این قیدها قبل از فعل اصلی می‌آیند: I **usually** walk to school.',
            '### منفی و سؤالی با do/does',
            '- I **don’t** work on Friday.',
            '- **Does** he play football? — او فوتبال بازی می‌کند؟',
            '- She **doesn’t** like coffee.',
            '> اشتباه رایج: ❌ He don’t work. ✅ He doesn’t work.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'wake up', fa: 'بیدار شدن', ipa: '/weɪk ʌp/' },
            { en: 'usually', fa: 'معمولاً', ipa: '/ˈjuː.ʒu.ə.li/' },
            { en: 'always', fa: 'همیشه', ipa: '/ˈɔːl.weɪz/' },
            { en: 'routine', fa: 'روزمره، روتین', ipa: '/ruːˈtiːn/' }
          ],
          quiz: [
            { q: 'جای خالی: He ___ to work by bus.', options: ['go', 'goes', 'going', 'is go'], answer: 1, why: 'برای سوم‌شخص مفرد فعل s می‌گیرد: goes.' },
            { q: 'کدام جمله منفی درست است؟', options: ['She don’t like tea.', 'She doesn’t like tea.', 'She not like tea.', 'She doesn’t likes tea.'], answer: 1, why: 'با she از doesn’t و فعل ساده استفاده می‌شود.' },
            { q: 'قید usually کجا می‌آید؟', options: ['I usually go to school.', 'I go usually to school.', 'Usually I go to school?', 'I go to usually school.'], answer: 0, why: 'قید تکرار قبل از فعل اصلی می‌آید.' }
          ]
        }
      ]
    },
    {
      n: 2,
      title: 'مکالمه روزمره',
      description: 'موقعیت‌های واقعی سفر، رستوران، پزشک و مصاحبه شغلی با جمله‌های آماده.',
      level: 2,
      color: 'teal',
      lessons: [
        {
          title: 'در فرودگاه',
          content: [
            '## از ورود تا سوار شدن',
            'در فرودگاه بیشترین جمله‌ها درباره بلیت، بار و دروازه پرواز است.',
            '### جمله‌های کلیدی',
            '- I’d like to check in, please. — می‌خواهم چک‌این کنم.',
            '- Here is my passport and ticket. — این پاسپورت و بلیت من است.',
            '- How many bags are you checking? — چند چمدان تحویل می‌دهید؟',
            '- Which gate is my flight? — پرواز من از کدام دروازه است؟',
            '- Is the flight delayed? — پرواز تأخیر دارد؟',
            '### گفت‌وگوی نمونه',
            '**Agent:** Good morning. May I see your passport?',
            '**You:** Good morning. Here you are.',
            '**Agent:** Are you checking any bags?',
            '**You:** Just one, please. And I’d like a window seat.',
            '**Agent:** Here is your boarding pass. Boarding starts at 10:30.',
            '> نکته: «Here you are» یعنی «بفرمایید» و در همه موقعیت‌ها کاربرد دارد.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'boarding pass', fa: 'کارت پرواز', ipa: '/ˈbɔː.dɪŋ pɑːs/' },
            { en: 'passport', fa: 'پاسپورت', ipa: '/ˈpɑːs.pɔːt/' },
            { en: 'delayed', fa: 'به‌تأخیرافتاده', ipa: '/dɪˈleɪd/' },
            { en: 'luggage', fa: 'بار و چمدان', ipa: '/ˈlʌɡ.ɪdʒ/' }
          ],
          quiz: [
            { q: '«کارت پرواز» کدام است؟', options: ['boarding pass', 'bus pass', 'passport', 'ticket office'], answer: 0, why: 'boarding pass کارت پرواز است.' },
            { q: 'Which gate… یعنی چه؟', options: ['کدام پرواز؟', 'کدام دروازه؟', 'کدام صندلی؟', 'کدام بلیت؟'], answer: 1, why: 'gate در فرودگاه یعنی دروازه پرواز.' },
            { q: 'پاسخ مؤدبانه هنگام دادن پاسپورت چیست؟', options: ['Give you.', 'Here you are.', 'Take it.', 'I am here.'], answer: 1, why: 'Here you are یعنی بفرمایید.' }
          ]
        },
        {
          title: 'در رستوران',
          content: [
            '## سفارش غذا',
            'در رستوران معمولاً میز می‌خواهیم، سفارش می‌دهیم و در پایان صورت‌حساب می‌خواهیم.',
            '### جمله‌های کلیدی',
            '- A table for two, please. — یک میز برای دو نفر.',
            '- Could I see the menu? — می‌توانم منو را ببینم؟',
            '- I’ll have the chicken, please. — مرغ می‌خورم.',
            '- Does this contain nuts? — این آجیل دارد؟',
            '- Could we have the bill, please? — می‌شود صورت‌حساب را بیاورید؟',
            '- Is service included? — انعام/سرویس حساب شده است؟',
            '### ایده‌های سفارش',
            'برای مؤدب بودن از **Could I…** و **I’d like…** استفاده کن؛ «I want» خیلی مستقیم است.',
            '> تمرین: یک سفارش سه‌مرحله‌ای بنویس: نوشیدنی، غذای اصلی، دسر.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'menu', fa: 'منو', ipa: '/ˈmen.juː/' },
            { en: 'bill', fa: 'صورت‌حساب', ipa: '/bɪl/' },
            { en: 'starter', fa: 'پیش‌غذا', ipa: '/ˈstɑː.tər/' },
            { en: 'dessert', fa: 'دسر', ipa: '/dɪˈzɜːt/' }
          ],
          quiz: [
            { q: 'مؤدبانه‌ترین درخواست کدام است؟', options: ['Give me water.', 'I want water.', 'Could I have some water, please?', 'Water!'], answer: 2, why: 'Could I have… please ساختار مؤدبانه است.' },
            { q: '«صورت‌حساب» کدام است؟', options: ['menu', 'bill', 'tip', 'order'], answer: 1, why: 'bill صورت‌حساب رستوران است.' },
            { q: 'starter یعنی چه؟', options: ['دسر', 'نوشیدنی', 'پیش‌غذا', 'غذای اصلی'], answer: 2, why: 'starter یا appetizer پیش‌غذا است.' }
          ]
        },
        {
          title: 'مراجعه به پزشک',
          content: [
            '## توضیح مشکل سلامتی',
            'در مطب باید علامت‌ها را ساده و دقیق توضیح بدهی.',
            '### جمله‌های کلیدی',
            '- I have a headache. — سردرد دارم.',
            '- I’ve had a fever since yesterday. — از دیروز تب دارم.',
            '- It hurts here. — اینجا درد می‌کند.',
            '- I’m allergic to penicillin. — به پنی‌سیلین حساسیت دارم.',
            '- Do I need a prescription? — نسخه لازم دارم؟',
            '### گفت‌وگوی نمونه',
            '**Doctor:** What seems to be the problem?',
            '**You:** I have a sore throat and a cough.',
            '**Doctor:** How long have you had these symptoms?',
            '**You:** For three days.',
            '**Doctor:** Take this medicine twice a day after meals.',
            '> نکته: برای مدت زمان از **for** و برای نقطه شروع از **since** استفاده کن: for three days / since Monday.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'headache', fa: 'سردرد', ipa: '/ˈhed.eɪk/' },
            { en: 'fever', fa: 'تب', ipa: '/ˈfiː.vər/' },
            { en: 'prescription', fa: 'نسخه', ipa: '/prɪˈskrɪp.ʃən/' },
            { en: 'symptoms', fa: 'نشانه‌های بیماری', ipa: '/ˈsɪmp.təmz/' }
          ],
          quiz: [
            { q: '«سردرد دارم» کدام است؟', options: ['I have a headache.', 'I am headache.', 'My head is pain.', 'I have head.'], answer: 0, why: 'با بیماری‌ها از have استفاده می‌شود.' },
            { q: 'برای «از دیروز» کدام واژه؟', options: ['for', 'since', 'from', 'during'], answer: 1, why: 'since برای نقطه شروع و for برای مدت است.' },
            { q: 'prescription یعنی چه؟', options: ['داروخانه', 'نسخه پزشک', 'بیمه', 'ویزیت'], answer: 1, why: 'prescription نسخه دارو است.' }
          ]
        },
        {
          title: 'مصاحبه شغلی',
          content: [
            '## معرفی توانایی‌ها',
            'در مصاحبه باید کوتاه، مشخص و مثبت درباره تجربه‌ات صحبت کنی.',
            '### جمله‌های کلیدی',
            '- Tell me about yourself. — درباره خودت بگو.',
            '- I have three years of experience in sales. — سه سال تجربه فروش دارم.',
            '- I’m good at working in a team. — در کار تیمی خوب هستم.',
            '- My strength is problem-solving. — نقطه قوتم حل مسئله است.',
            '- Could you tell me more about the role? — می‌شود درباره این نقش بیشتر توضیح دهید؟',
            '### ساختار پاسخ کوتاه',
            '۱) وضعیت فعلی ۲) تجربه مرتبط ۳) دلیل علاقه به این شغل.',
            '**نمونه:** I’m a customer support specialist with three years of experience. I enjoy helping people and solving problems quickly. I’m interested in this role because it combines both.',
            '> نکته: از پاسخ‌های خیلی کوتاه (Yes/No) پرهیز کن؛ هر پاسخ را با یک مثال کامل کن.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'experience', fa: 'تجربه', ipa: '/ɪkˈspɪə.ri.əns/' },
            { en: 'team', fa: 'تیم', ipa: '/tiːm/' },
            { en: 'strength', fa: 'نقطه قوت', ipa: '/streŋθ/' },
            { en: 'role', fa: 'نقش شغلی', ipa: '/rəʊl/' }
          ],
          quiz: [
            { q: '«سه سال تجربه دارم» کدام است؟', options: ['I have three years experience.', 'I have three years of experience.', 'I am three years experience.', 'I has experience three years.'], answer: 1, why: 'ساختار درست: years of experience.' },
            { q: 'My strength is… یعنی چه؟', options: ['نقطه ضعف من…', 'نقطه قوت من…', 'علاقه من…', 'سابقه من…'], answer: 1, why: 'strength نقطه قوت است.' },
            { q: 'کدام جمله برای مصاحبه مناسب‌تر است؟', options: ['I don’t know.', 'I’m good at working in a team.', 'Whatever.', 'It’s not important.'], answer: 1, why: 'بیان توانایی با مثال، پاسخ حرفه‌ای است.' }
          ]
        },
        {
          title: 'مکالمه تلفنی',
          content: [
            '## شروع و پایان تماس',
            'در تماس تلفنی چون چهره‌ها دیده نمی‌شوند، وضوح و ادب مهم‌تر است.',
            '### جمله‌های کلیدی',
            '- Hello, this is Sara speaking. — سلام، سارا صحبت می‌کند.',
            '- May I speak to Mr. Ahmad? — می‌توانم با آقای احمد صحبت کنم؟',
            '- Could you hold on a moment? — یک لحظه منتظر بمانید؟',
            '- I’m afraid he’s not available. — متأسفانه ایشان در دسترس نیستند.',
            '- Could you repeat that, please? — می‌شود تکرار کنید؟',
            '- I’ll call back later. — بعداً تماس می‌گیرم.',
            '### پیام گذاشتن',
            'Can I leave a message? — می‌توانم پیام بگذارم؟',
            'Could you ask him to call me back? — می‌شود از او بخواهید تماس بگیرد؟',
            '> نکته: در انگلیسی تلفنی «Who are you?» خیلی مستقیم است؛ به‌جای آن بگو «May I ask who’s calling?»'
          ].join('\n\n'),
          vocabulary: [
            { en: 'hold on', fa: 'منتظر ماندن', ipa: '/həʊld ɒn/' },
            { en: 'available', fa: 'در دسترس', ipa: '/əˈveɪ.lə.bəl/' },
            { en: 'message', fa: 'پیام', ipa: '/ˈmes.ɪdʒ/' },
            { en: 'call back', fa: 'تماس گرفتن (دوباره)', ipa: '/kɔːl bæk/' }
          ],
          quiz: [
            { q: '«سارا صحبت می‌کند» کدام است؟', options: ['This is Sara speaking.', 'I am Sara speak.', 'Sara is talking you.', 'Here Sara.'], answer: 0, why: 'عبارت رایج تلفنی: This is … speaking.' },
            { q: '«می‌شود تکرار کنید؟» کدام است؟', options: ['Say again.', 'Could you repeat that, please?', 'What?', 'Repeat you.'], answer: 1, why: 'درخواست مؤدبانه تکرار: Could you repeat that, please?' },
            { q: 'available یعنی چه؟', options: ['مشغول', 'در دسترس', 'خارج از کشور', 'بیمار'], answer: 1, why: 'available یعنی در دسترس بودن.' }
          ]
        },
        {
          title: 'پرسیدن آدرس',
          content: [
            '## مسیر را چطور بپرسیم',
            'برای پرسیدن مسیر از ساختارهای مؤدبانه و کوتاه استفاده کن.',
            '### جمله‌های کلیدی',
            '- Excuse me, where is the nearest bank? — ببخشید، نزدیک‌ترین بانک کجاست؟',
            '- How do I get to the station? — چطور به ایستگاه بروم؟',
            '- Is it far from here? — از اینجا دور است؟',
            '- Turn left at the traffic lights. — سر چراغ راهنمایی به چپ بپیچ.',
            '- Go straight for two blocks. — دو بلوک مستقیم برو.',
            '- It’s on your right. — سمت راست شماست.',
            '### شنیدن مسیر',
            'معمولاً سه بخش دارد: جهت (left/right)، نشانه (traffic lights, corner)، فاصله (two blocks, five minutes).',
            '> تمرین: مسیر خانه تا نزدیک‌ترین داروخانه را به انگلیسی در سه جمله بنویس.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'nearest', fa: 'نزدیک‌ترین', ipa: '/ˈnɪə.rɪst/' },
            { en: 'traffic lights', fa: 'چراغ راهنمایی', ipa: '/ˈtræf.ɪk laɪts/' },
            { en: 'block', fa: 'بلوک، گذر', ipa: '/blɒk/' },
            { en: 'straight', fa: 'مستقیم', ipa: '/streɪt/' }
          ],
          quiz: [
            { q: '«نزدیک‌ترین بانک کجاست؟» کدام است؟', options: ['Where nearest bank?', 'Where is the nearest bank?', 'Which nearest bank?', 'Where bank near?'], answer: 1, why: 'ساختار درست: Where is the nearest bank?' },
            { q: '«مستقیم برو» کدام است؟', options: ['Go straight.', 'Go left.', 'Turn back.', 'Stop here.'], answer: 0, why: 'Go straight یعنی مستقیم برو.' },
            { q: 'It’s on your right یعنی چه؟', options: ['سمت چپ شماست', 'سمت راست شماست', 'روبه‌روی شماست', 'پشت سر شماست'], answer: 1, why: 'on your right یعنی سمت راست.' }
          ]
        }
      ]
    },
    {
      n: 3,
      title: 'گرامر و ساختار',
      description: 'زمان‌های کلیدی، جملات شرطی، مجهول و نقل قول برای سطح متوسط به بالا.',
      level: 3,
      color: 'violet',
      lessons: [
        {
          title: 'حال کامل (Present Perfect)',
          content: [
            '## تجربه و نتیجه تا امروز',
            'حال کامل پلی است بین گذشته و حال: کاری در گذشته انجام شده و نتیجه یا تجربه‌اش تا الان مهم است.',
            '### ساختار',
            'have / has + past participle (قسمت سوم فعل)',
            '- I **have visited** Istanbul twice. — دو بار استانبول بوده‌ام.',
            '- She **has finished** her homework. — او تکالیفش را تمام کرده است.',
            '### کاربردها',
            '- تجربه: Have you ever eaten sushi؟',
            '- نتیجه در حال: I have lost my keys. (الان کلید ندارم)',
            '- ادامه تا حالا: I have lived here for five years.',
            '### تفاوت با گذشته ساده',
            'گذشته ساده زمان مشخص دارد: I visited Istanbul **in 2019**.',
            'حال کامل زمان مشخص ندارد: I **have visited** Istanbul.',
            '> اشتباه رایج: ❌ I have seen him yesterday. ✅ I saw him yesterday.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'experience', fa: 'تجربه', ipa: '/ɪkˈspɪə.ri.əns/' },
            { en: 'already', fa: 'قبلاً، تا حالا', ipa: '/ɔːlˈred.i/' },
            { en: 'yet', fa: 'هنوز (در سؤال/منفی)', ipa: '/jet/' },
            { en: 'ever', fa: 'تا به حال', ipa: '/ˈev.ər/' }
          ],
          quiz: [
            { q: 'جای خالی: She ___ finished the report.', options: ['have', 'has', 'is', 'did'], answer: 1, why: 'برای she از has + past participle استفاده می‌شود.' },
            { q: 'کدام جمله درست است؟', options: ['I have seen him yesterday.', 'I saw him yesterday.', 'I have saw him yesterday.', 'I seen him yesterday.'], answer: 1, why: 'با زمان مشخص گذشته (yesterday) از گذشته ساده استفاده می‌شود.' },
            { q: '«تا حالا sushi خورده‌ای؟» کدام است؟', options: ['Did you ever eat sushi?', 'Have you ever eaten sushi?', 'Do you ever ate sushi?', 'Are you ever eating sushi?'], answer: 1, why: 'سؤال تجربه با Have you ever + past participle ساخته می‌شود.' }
          ]
        },
        {
          title: 'گذشته استمراری',
          content: [
            '## کاری در جریان گذشته',
            'گذشته استمراری نشان می‌دهد کاری در نقطه‌ای از گذشته در حال انجام بود.',
            '### ساختار',
            'was / were + verb + ing',
            '- I **was reading** when he called. — داشتم می‌خواندم که زنگ زد.',
            '- They **were playing** football at 5 p.m.',
            '### گذشته استمراری + گذشته ساده',
            'کاری طولانی (استمراری) با کاری کوتاه (ساده) قطع می‌شود:',
            'She **was cooking** dinner **when** the power **went** out.',
            '### while و when',
            '- **while** + گذشته استمراری: While I was walking, it started to rain.',
            '- **when** + گذشته ساده: I was walking when it started to rain.',
            '> نکته: افعال حالتی مثل know, like, want معمولاً استمراری نمی‌شوند: ❌ I was knowing.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'while', fa: 'در حالی که', ipa: '/waɪl/' },
            { en: 'interrupt', fa: 'قطع کردن', ipa: '/ˌɪn.təˈrʌpt/' },
            { en: 'power', fa: 'برق', ipa: '/ˈpaʊ.ər/' },
            { en: 'at that moment', fa: 'در آن لحظه', ipa: '/ət ðæt ˈməʊ.mənt/' }
          ],
          quiz: [
            { q: 'جای خالی: They ___ football when it started to rain.', options: ['played', 'were playing', 'are playing', 'play'], answer: 1, why: 'کار در جریان گذشته با گذشته استمراری بیان می‌شود.' },
            { q: 'کدام فعل معمولاً استمراری نمی‌شود؟', options: ['run', 'know', 'read', 'play'], answer: 1, why: 'know فعل حالتی است و معمولاً استمراری نمی‌شود.' },
            { q: 'while با کدام زمان طبیعی‌تر است؟', options: ['گذشته ساده', 'گذشته استمراری', 'حال کامل', 'آینده'], answer: 1, why: 'while معمولاً با گذشته استمراری می‌آید.' }
          ]
        },
        {
          title: 'جملات شرطی',
          content: [
            '## اگر… آنگاه…',
            'شرطی‌ها رابطه شرط و نتیجه را نشان می‌دهند و چهار نوع اصلی دارند.',
            '### نوع صفر (حقیقت)',
            'If + حال ساده، حال ساده: If you heat ice, it melts.',
            '### نوع اول (آینده ممکن)',
            'If + حال ساده، will + فعل: If it rains, we will stay home.',
            '### نوع دوم (فرضی/غیرواقعی در حال)',
            'If + گذشته ساده، would + فعل: If I had more time, I would travel.',
            '### نوع سوم (پشیمانی از گذشته)',
            'If + had + p.p.، would have + p.p.: If I had studied, I would have passed.',
            '> نکته: در جمله شرطی هرگز will را بعد از if نیاور: ❌ If it will rain…'
          ].join('\n\n'),
          vocabulary: [
            { en: 'condition', fa: 'شرط', ipa: '/kənˈdɪʃ.ən/' },
            { en: 'result', fa: 'نتیجه', ipa: '/rɪˈzʌlt/' },
            { en: 'unless', fa: 'مگر اینکه', ipa: '/ənˈles/' },
            { en: 'imagine', fa: 'تصور کردن', ipa: '/ɪˈmædʒ.ɪn/' }
          ],
          quiz: [
            { q: 'جای خالی: If it rains, we ___ at home.', options: ['stay', 'will stay', 'stayed', 'would stay'], answer: 1, why: 'شرطی نوع اول: if + حال ساده، will + فعل.' },
            { q: 'کدام جمله درست است؟', options: ['If I will see him, I will tell him.', 'If I see him, I will tell him.', 'If I saw him, I will tell him.', 'If I see him, I would told him.'], answer: 1, why: 'بعد از if فعل آینده با will نمی‌آید.' },
            { q: 'شرطی نوع سوم چه چیزی را بیان می‌کند؟', options: ['حقیقت علمی', 'آینده ممکن', 'فرض غیرواقعی در گذشته', 'عادت روزانه'], answer: 2, why: 'نوع سوم درباره گذشته غیرواقعی و پشیمانی است.' }
          ]
        },
        {
          title: 'مجهول (Passive Voice)',
          content: [
            '## وقتی فاعل مهم نیست',
            'در جمله مجهول، تمرکز روی مفعول یا اتفاق است، نه انجام‌دهنده.',
            '### ساختار',
            'be + past participle',
            '- The letter **was written** by Ali. — نامه توسط علی نوشته شد.',
            '- English **is spoken** all over the world.',
            '### در زمان‌های مختلف',
            '- حال ساده: The office **is cleaned** every day.',
            '- گذشته ساده: The bridge **was built** in 1990.',
            '- حال کامل: The report **has been sent**.',
            '- آینده: The results **will be announced** tomorrow.',
            '### چه زمانی مجهول؟',
            'وقتی انجام‌دهنده ناشناخته، بی‌اهمیت یا واضح است؛ در نوشتار رسمی و خبری رایج است.',
            '> نکته: فقط افعال گذرا (که مفعول دارند) مجهول می‌شوند.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'passive', fa: 'مجهول', ipa: '/ˈpæs.ɪv/' },
            { en: 'announce', fa: 'اعلام کردن', ipa: '/əˈnaʊns/' },
            { en: 'build', fa: 'ساختن', ipa: '/bɪld/' },
            { en: 'by', fa: 'توسط', ipa: '/baɪ/' }
          ],
          quiz: [
            { q: 'مجهول جمله «They built the bridge in 1990» کدام است؟', options: ['The bridge built in 1990.', 'The bridge was built in 1990.', 'The bridge is build in 1990.', 'The bridge has built in 1990.'], answer: 1, why: 'گذشته ساده مجهول: was/were + past participle.' },
            { q: 'ساختار کلی مجهول چیست؟', options: ['have + p.p.', 'be + p.p.', 'do + p.p.', 'will + ing'], answer: 1, why: 'مجهول با be + past participle ساخته می‌شود.' },
            { q: 'کدام جمله مجهول است؟', options: ['She wrote a letter.', 'A letter was written.', 'She is writing.', 'She has a letter.'], answer: 1, why: 'A letter was written ساختار مجهول دارد.' }
          ]
        },
        {
          title: 'نقل قول غیرمستقیم',
          content: [
            '## بازگویی حرف دیگران',
            'در نقل قول غیرمستقیم، جمله را یک مرحله به عقب در زمان می‌بریم.',
            '### تغییر زمان‌ها',
            '- حال ساده → گذشته ساده: “I am tired” → He said he **was** tired.',
            '- گذشته ساده → گذشته کامل: “I saw her” → He said he **had seen** her.',
            '- will → would: “I will call” → She said she **would** call.',
            '### تغییر ضمیر و قید زمان',
            '- today → that day، tomorrow → the next day، here → there.',
            '### say و tell',
            '- say + جمله: He said (that) he was busy.',
            '- tell + شخص: He told **me** he was busy.',
            '> نکته: اگر حرف هنوز معتبر است، تغییر زمان لازم نیست: She said she **is** on her way.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'report', fa: 'نقل کردن', ipa: '/rɪˈpɔːt/' },
            { en: 'direct', fa: 'مستقیم', ipa: '/dəˈrekt/' },
            { en: 'indirect', fa: 'غیرمستقیم', ipa: '/ˌɪn.dəˈrekt/' },
            { en: 'explain', fa: 'توضیح دادن', ipa: '/ɪkˈspleɪn/' }
          ],
          quiz: [
            { q: '“I will call you” → She said she ___ call me.', options: ['will', 'would', 'can', 'did'], answer: 1, why: 'will در نقل قول غیرمستقیم به would تبدیل می‌شود.' },
            { q: 'کدام ساختار با tell درست است؟', options: ['He told that he was late.', 'He told me he was late.', 'He told to me late.', 'He told me was late.'], answer: 1, why: 'tell نیاز به مفعول شخص دارد: told me.' },
            { q: '“I am busy” → He said he ___ busy.', options: ['is', 'was', 'were', 'be'], answer: 1, why: 'حال ساده در نقل غیرمستقیم به گذشته ساده تبدیل می‌شود.' }
          ]
        },
        {
          title: 'جملات موصولی',
          content: [
            '## وصل کردن اطلاعات',
            'جملات موصولی با who, which, that, whose اطلاعات بیشتری درباره اسم می‌دهند.',
            '### ضمایر موصولی',
            '- **who** برای انسان: The teacher **who** helped me was kind.',
            '- **which** برای اشیا: The book **which** I bought is interesting.',
            '- **that** برای هر دو (غیررسمی): The car **that** he drives is old.',
            '- **whose** برای مالکیت: The student **whose** phone rang was embarrassed.',
            '### موصولی محدودکننده و غیرمحدودکننده',
            '- محدودکننده: اطلاعات ضروری است و کاما ندارد.',
            '- غیرمحدودکننده: اطلاعات اضافی است و بین دو کاما می‌آید: My brother, **who lives in Dubai**, is a doctor.',
            '> نکته: در موصولی غیرمحدودکننده از that استفاده نمی‌کنیم.'
          ].join('\n\n'),
          vocabulary: [
            { en: 'relative clause', fa: 'جمله موصولی', ipa: '/ˈrel.ə.tɪv klɔːz/' },
            { en: 'whose', fa: 'که مالِ…', ipa: '/huːz/' },
            { en: 'describe', fa: 'توصیف کردن', ipa: '/dɪˈskraɪb/' },
            { en: 'necessary', fa: 'ضروری', ipa: '/ˈnes.ə.ser.i/' }
          ],
          quiz: [
            { q: 'برای انسان کدام ضمیر موصولی مناسب است؟', options: ['which', 'who', 'whose', 'where'], answer: 1, why: 'who برای انسان استفاده می‌شود.' },
            { q: 'جای خالی: The book ___ I read was great.', options: ['who', 'which', 'whose', 'whom'], answer: 1, why: 'برای اشیا از which یا that استفاده می‌شود.' },
            { q: 'whose چه چیزی را نشان می‌دهد؟', options: ['مکان', 'زمان', 'مالکیت', 'دلیل'], answer: 2, why: 'whose مالکیت را بیان می‌کند.' }
          ]
        }
      ]
    }
  ];

  var grammar = [
    {
      title: 'حروف تعریف a / an / the',
      category: 'پایه',
      content: [
        '«a» و «an» برای اسم مفرد قابل‌شمارش و ناشناخته به کار می‌روند؛ «the» برای چیزی که برای شنونده مشخص است.',
        'انتخاب a یا an بر اساس **صدا** است نه حرف: an hour (h تلفظ نمی‌شود) اما a university (صدای /juː/).'
      ].join('\n\n'),
      examples: 'a book — یک کتاب\nan apple — یک سیب\nthe sun — خورشید (مشخص)\nan hour — یک ساعت\nI saw a dog. The dog was black.'
    },
    {
      title: 'حال ساده',
      category: 'زمان‌ها',
      content: 'برای عادت‌ها، برنامه‌های ثابت و حقایق. برای سوم‌شخص مفرد به فعل s اضافه می‌شود و در منفی/سؤالی از does استفاده می‌کنیم.',
      examples: 'I play football every Friday.\nShe works at a bank.\nHe doesn’t like coffee.\nDo they live here?'
    },
    {
      title: 'گذشته ساده',
      category: 'زمان‌ها',
      content: 'برای کاری که در گذشته تمام شده و زمان آن مشخص است. افعال باقاعده ed می‌گیرند و افعال بی‌قاعده شکل خاص دارند.',
      examples: 'I watched a movie last night.\nHe went home early.\nWe didn’t see the match.\nDid you call her?'
    },
    {
      title: 'حال کامل',
      category: 'زمان‌ها',
      content: 'برای تجربه‌ها، نتیجه‌های تا امروز و کارهایی که ادامه دارند. با قیدهای already, yet, ever, never, since, for می‌آید.',
      examples: 'I have visited Istanbul twice.\nShe has just arrived.\nHave you ever tried sushi?\nI have lived here since 2019.'
    },
    {
      title: 'جملات شرطی',
      category: 'ساختار',
      content: 'چهار نوع شرطی داریم: صفر (حقیقت)، اول (آینده ممکن)، دوم (فرض غیرواقعی حال) و سوم (پشیمانی گذشته).',
      examples: 'If you heat ice, it melts.\nIf it rains, we will stay home.\nIf I had time, I would travel.\nIf I had studied, I would have passed.'
    },
    {
      title: 'مجهول',
      category: 'ساختار',
      content: 'وقتی انجام‌دهنده مهم نیست یا ناشناخته است از be + past participle استفاده می‌کنیم.',
      examples: 'English is spoken worldwide.\nThe letter was written yesterday.\nThe report has been sent.\nThe results will be announced tomorrow.'
    },
    {
      title: 'افعال کمکی وجهی',
      category: 'ساختار',
      content: 'can, could, may, might, must, should, have to توانایی، اجازه، احتمال و اجبار را بیان می‌کنند. بعد از آن‌ها فعل ساده می‌آید.',
      examples: 'I can swim.\nYou should rest.\nIt might rain later.\nWe have to wear a uniform.'
    },
    {
      title: 'جملات موصولی',
      category: 'ساختار',
      content: 'who برای انسان، which برای اشیا، that برای هر دو و whose برای مالکیت به کار می‌رود.',
      examples: 'The man who called is my uncle.\nThe book which I bought is great.\nThe car that he drives is old.\nThe girl whose bag was lost is here.'
    },
    {
      title: 'نقل قول غیرمستقیم',
      category: 'ساختار',
      content: 'در بازگویی حرف دیگران زمان یک مرحله عقب می‌رود و ضمیرها و قیدهای زمان تغییر می‌کنند.',
      examples: '“I am tired.” → He said he was tired.\n“I will call.” → She said she would call.\n“I saw her.” → He said he had seen her.'
    },
    {
      title: 'اسم‌های قابل‌شمارش و غیرقابل‌شمارش',
      category: 'پایه',
      content: 'اسم‌های غیرقابل‌شمارش (water, information, advice) جمع بسته نمی‌شوند و با much/little می‌آیند؛ قابل‌شمارش با many/few.',
      examples: 'How much water do you need?\nHow many books did you buy?\nShe gave me some advice.\nThere is a lot of information.'
    },
    {
      title: 'صفات تفضیلی و عالی',
      category: 'پایه',
      content: 'برای مقایسه: صفت کوتاه + er / est؛ صفت بلند با more / most. بی‌قاعده‌ها را حفظ کن.',
      examples: 'This book is cheaper than that one.\nShe is the tallest student.\nThis is more interesting.\nIt was the best day.'
    },
    {
      title: 'حروف اضافه مکان و زمان',
      category: 'پایه',
      content: 'in برای فضای بسته و ماه/سال، on برای سطح و روز، at برای نقطه و ساعت.',
      examples: 'at 7 o’clock\non Monday\nin July\nin the room\nat the bus stop'
    }
  ];

  var listening = [
    {
      n: 1,
      title: 'در فرودگاه: چک‌این',
      level: 2,
      description: 'گفت‌وگوی مسافر و کارمند فرودگاه درباره بار و کارت پرواز.',
      lines: [
        { s: 'Agent', t: 'Good morning. May I see your passport, please?' },
        { s: 'You', t: 'Good morning. Here you are.' },
        { s: 'Agent', t: 'Thank you. Are you checking any bags today?' },
        { s: 'You', t: 'Yes, just one. And I would like a window seat.' },
        { s: 'Agent', t: 'Certainly. Your flight leaves from gate twelve at ten thirty.' },
        { s: 'You', t: 'Is the flight on time?' },
        { s: 'Agent', t: 'Yes, it is. Boarding starts at ten o’clock.' }
      ],
      questions: [
        { q: 'مسافر چند چمدان تحویل می‌دهد؟', options: ['دو', 'یک', 'سه', 'هیچ'], answer: 1, why: 'مسافر می‌گوید: just one.' },
        { q: 'پرواز از کدام دروازه است؟', options: ['دروازه ۱۰', 'دروازه ۱۲', 'دروازه ۲۰', 'دروازه ۲'], answer: 1, why: 'کارمند می‌گوید gate twelve.' }
      ]
    },
    {
      n: 2,
      title: 'در رستوران: سفارش',
      level: 2,
      description: 'سفارش غذا و نوشیدنی و درخواست صورت‌حساب.',
      lines: [
        { s: 'Waiter', t: 'Good evening. Are you ready to order?' },
        { s: 'You', t: 'Yes, I would like the grilled chicken, please.' },
        { s: 'Waiter', t: 'Would you like rice or salad with that?' },
        { s: 'You', t: 'Salad, please. And a glass of water.' },
        { s: 'Waiter', t: 'Anything else?' },
        { s: 'You', t: 'No, thank you. Could we have the bill later?' },
        { s: 'Waiter', t: 'Of course.' }
      ],
      questions: [
        { q: 'مسافر چه غذایی سفارش می‌دهد؟', options: ['مرغ کبابی', 'ماهی', 'پاستا', 'سوپ'], answer: 0, why: 'the grilled chicken یعنی مرغ کبابی.' },
        { q: 'همراه غذا چه چیزی انتخاب می‌کند؟', options: ['برنج', 'سالاد', 'سیب‌زمینی', 'نان'], answer: 1, why: 'پاسخ می‌دهد: Salad, please.' }
      ]
    },
    {
      n: 3,
      title: 'در مطب پزشک',
      level: 2,
      description: 'توضیح علائم بیماری و دریافت نسخه.',
      lines: [
        { s: 'Doctor', t: 'What seems to be the problem?' },
        { s: 'You', t: 'I have a sore throat and a headache.' },
        { s: 'Doctor', t: 'How long have you had these symptoms?' },
        { s: 'You', t: 'For about three days.' },
        { s: 'Doctor', t: 'Do you have a fever?' },
        { s: 'You', t: 'Yes, a little.' },
        { s: 'Doctor', t: 'Take this medicine twice a day after meals and rest.' }
      ],
      questions: [
        { q: 'علائم مسافر از چه زمانی شروع شده؟', options: ['از دیروز', 'حدود سه روز', 'یک هفته', 'یک ماه'], answer: 1, why: 'می‌گوید for about three days.' },
        { q: 'دارو را چگونه مصرف کند؟', options: ['روزی یک‌بار', 'روزی دو بار بعد از غذا', 'قبل از خواب', 'هر ساعت'], answer: 1, why: 'twice a day after meals یعنی روزی دو بار بعد از غذا.' }
      ]
    },
    {
      n: 4,
      title: 'تماس تلفنی اداری',
      level: 2,
      description: 'درخواست صحبت با مدیر و گذاشتن پیام.',
      lines: [
        { s: 'Receptionist', t: 'Good afternoon, Star Company. How can I help you?' },
        { s: 'You', t: 'Hello. May I speak to Mr. Ahmad, please?' },
        { s: 'Receptionist', t: 'I am afraid he is in a meeting. May I ask who is calling?' },
        { s: 'You', t: 'This is Sara Karimi from Nova Design.' },
        { s: 'Receptionist', t: 'Would you like to leave a message?' },
        { s: 'You', t: 'Yes, please ask him to call me back before five.' },
        { s: 'Receptionist', t: 'Certainly. I will pass on your message.' }
      ],
      questions: [
        { q: 'چرا مدیر پاسخ نمی‌دهد؟', options: ['در سفر است', 'در جلسه است', 'مرخصی است', 'در ناهار است'], answer: 1, why: 'منشی می‌گوید he is in a meeting.' },
        { q: 'سارا چه درخواستی دارد؟', options: ['تماس تا قبل از پنج', 'ارسال ایمیل', 'ملاقات حضوری', 'ارسال فکس'], answer: 0, why: 'می‌گوید call me back before five.' }
      ]
    },
    {
      n: 5,
      title: 'پرسیدن مسیر در شهر',
      level: 1,
      description: 'پیدا کردن نزدیک‌ترین ایستگاه اتوبوس.',
      lines: [
        { s: 'You', t: 'Excuse me, where is the nearest bus station?' },
        { s: 'Local', t: 'Go straight for two blocks, then turn left at the bank.' },
        { s: 'You', t: 'Is it far from here?' },
        { s: 'Local', t: 'No, it is about five minutes on foot.' },
        { s: 'You', t: 'Thank you very much.' },
        { s: 'Local', t: 'You are welcome. Have a nice day.' }
      ],
      questions: [
        { q: 'ایستگاه چند دقیقه پیاده فاصله دارد؟', options: ['دو دقیقه', 'پنج دقیقه', 'ده دقیقه', 'بیست دقیقه'], answer: 1, why: 'می‌گوید about five minutes on foot.' },
        { q: 'کجا باید به چپ بپیچد؟', options: ['سر بانک', 'سر مدرسه', 'سر پارک', 'سر بیمارستان'], answer: 0, why: 'turn left at the bank.' }
      ]
    }
  ];

  var vocabExtra = [
    { en: 'improve', fa: 'بهبود دادن', ipa: '/ɪmˈpruːv/' },
    { en: 'practice', fa: 'تمرین کردن', ipa: '/ˈpræk.tɪs/' },
    { en: 'confident', fa: 'با اعتمادبه‌نفس', ipa: '/ˈkɒn.fɪ.dənt/' },
    { en: 'mistake', fa: 'اشتباه', ipa: '/mɪˈsteɪk/' },
    { en: 'fluent', fa: 'روان', ipa: '/ˈfluː.ənt/' },
    { en: 'review', fa: 'مرور کردن', ipa: '/rɪˈvjuː/' }
  ];

  return {
    courses: courses,
    grammar: grammar,
    listening: listening,
    vocabExtra: vocabExtra,
    mk: mk
  };
})();
