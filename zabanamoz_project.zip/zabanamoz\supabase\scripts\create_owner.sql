-- ============================================================================
-- create_owner.sql — ساخت حساب مالک (Super Admin) — فقط یک‌بار!
-- ----------------------------------------------------------------------------
-- اجرا در: Supabase Dashboard → SQL Editor (اتصال با نقش postgres)
-- ⚠️ فقط خط «v_email» را با ایمیل خودت عوض کن و اجرا کن.
-- ⚠️ رمز عبور و کد break-glass فقط یک‌بار در بخش پیام‌ها (NOTICE) نمایش
--    داده می‌شوند — فوراً در جای امن (مثلاً Password Manager) ذخیره کن.
-- اجرای دوم اخطار می‌دهد و کاری انجام نمی‌دهد (قفل یک‌بارمصرف).
-- ============================================================================

do $$
declare
  -- ⬇️⬇️ فقط این خط را تغییر بده ⬇️⬇️
  v_email      text := 'REPLACE-WITH-YOUR-EMAIL@gmail.com';
  -- ⬆️⬆️ فقط این خط را تغییر بده ⬆️⬆️

  v_name       text := 'مالک';
  v_id         uuid;
  v_password   text;
  v_break_glass text;
  v_pw_hash    text;
  v_bg_hash    text;
  v_bg_raw     text;
  v_flags      jsonb;
  v_alnum      constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  v_code_set   constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
begin
  -- ---------- ۱) بررسی قفل یک‌بارمصرف ----------
  select value into v_flags
  from public.system_flags
  where key = 'owner_created';

  if v_flags is not null and (v_flags #>> '{}') = 'true' then
    raise exception 'مالک قبلاً ساخته شده است. این اسکریپت فقط یک‌بار اجرا می‌شود.';
  end if;

  -- ---------- ۲) اعتبارسنجی ایمیل ----------
  v_email := lower(btrim(coalesce(v_email, '')));
  if v_email like '%replace%' or v_email !~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$' then
    raise exception 'ابتدا ایمیل خود را در خط v_email وارد کن.';
  end if;

  if exists (select 1 from auth.users where lower(email) = v_email) then
    raise exception 'این ایمیل قبلاً در سیستم ثبت شده است.';
  end if;

  -- ---------- ۳) تولید رمز عبور قوی (۱۸ کاراکتر تصادفی) ----------
  select string_agg(
           substr(v_alnum, (floor(random() * length(v_alnum))::int) + 1, 1), ''
         )
    into v_password
    from generate_series(1, 16);
  v_password := 'Zb' || v_password || '9';

  -- ---------- ۴) تولید کد بازیابی اضطراری (break-glass) ----------
  -- قالب: XXXX-XXXX-XXXX-XXXX (۱۶ کاراکتر بی‌ابهام)
  select string_agg(
           substr(v_code_set, (floor(random() * length(v_code_set))::int) + 1, 1), ''
         )
    into v_bg_raw
    from generate_series(1, 16);
  v_break_glass := substr(v_bg_raw, 1, 4) || '-' || substr(v_bg_raw, 5, 4) || '-'
                || substr(v_bg_raw, 9, 4) || '-' || substr(v_bg_raw, 13, 4);

  -- ---------- ۵) هش‌کردن (bcrypt, cost 12) ----------
  v_pw_hash := extensions.crypt(v_password,     extensions.gen_salt('bf', 12));
  v_bg_hash := extensions.crypt(v_break_glass, extensions.gen_salt('bf', 12));

  -- ---------- ۶) ساخت کاربر در auth.users ----------
  v_id := gen_random_uuid();

  insert into auth.users (
    instance_id, id, aud, role, email, encrypted_password,
    email_confirmed_at, created_at, updated_at,
    raw_app_meta_data, raw_user_meta_data
  ) values (
    '00000000-0000-0000-0000-000000000000',
    v_id, 'authenticated', 'authenticated', v_email, v_pw_hash,
    now(), now(), now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    jsonb_build_object('name', v_name)
  );

  -- ثبت identity برای پروایدر ایمیل (سازگار با GoTrue)
  insert into auth.identities (
    id, user_id, provider_id, provider, identity_data,
    last_sign_in_at, created_at, updated_at
  ) values (
    v_id::text, v_id, v_id::text, 'email',
    jsonb_build_object('sub', v_id::text, 'email', v_email, 'email_verified', true),
    now(), now(), now()
  );
  -- (پروفایل به‌صورت خودکار توسط تریگر trg_on_auth_user_created ساخته می‌شود)

  -- ---------- ۷) نام پروفایل ----------
  update public.profiles
     set name = v_name
   where id = v_id;

  -- ---------- ۸) نقش super_admin (تریگر نگهبان چون auth.uid()=null اجازه می‌دهد) ----------
  insert into public.user_roles (user_id, role)
  values (v_id, 'super_admin');

  -- ---------- ۹) کد break-glass (فقط هش ذخیره می‌شود) ----------
  insert into public.owner_recovery (user_id, break_glass_hash)
  values (v_id, v_bg_hash);

  -- ---------- ۱۰) قفل ساخت مالک ----------
  update public.system_flags
     set value = 'true'::jsonb, updated_at = now()
   where key = 'owner_created';

  -- ---------- ۱۱) ثبت در لاگ امنیتی ----------
  perform public.fn_append_audit(
    'owner_created', v_id, null, null,
    jsonb_build_object('email', v_email)
  );

  -- ---------- ۱۲) نمایش یک‌بارمصرف اسرار ----------
  raise notice '==================================================================';
  raise notice '✅ حساب مالک ساخته شد.';
  raise notice 'ایمیل ورود : %', v_email;
  raise notice 'رمز عبور   : %', v_password;
  raise notice 'کد اضطراری (break-glass) : %', v_break_glass;
  raise notice '⚠️ همین حالا این سه مورد را جایی امن ذخیره کن — دوباره نمایش داده نمی‌شوند!';
  raise notice '==================================================================';
end;
$$;
