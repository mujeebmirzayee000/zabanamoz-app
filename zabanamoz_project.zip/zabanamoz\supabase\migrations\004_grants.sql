-- ============================================================================
-- زبان‌آموز — Migration 004: دسترسی service_role به توابع عملیاتی
-- ----------------------------------------------------------------------------
-- Edge Function ها با نقش service_role اجرا می‌شوند؛ چون در 001 دسترسی
-- public از این توابع گرفته شد، اینجا فقط به service_role برمی‌گردانیم.
-- اجرا: بعد از 001 در SQL Editor
-- ============================================================================

grant execute on function public.fn_record_admin_attempt(text, boolean, text, text)
  to service_role;

grant execute on function public.fn_get_admin_lock(text)
  to service_role;

grant execute on function public.fn_verify_break_glass(text, text)
  to service_role;

grant execute on function public.fn_append_audit(text, uuid, text, text, jsonb)
  to service_role;

grant execute on function public.fn_notify_alerts()
  to service_role;

-- service_role از RLS عبور می‌کند ولی برای اطمینان روی جدول‌های سیستمی
-- سیاست‌ها در 001 همین‌طور نوشته شده‌اند (postgres, service_role).
