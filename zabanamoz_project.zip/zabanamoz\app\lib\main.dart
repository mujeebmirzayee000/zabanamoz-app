import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'core/supabase_client.dart';
import 'core/theme.dart';
import 'router.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initSupabase();

  final authNotifier = AuthNotifier();
  sb.auth.onAuthStateChange.listen((_) => authNotifier.refresh());

  runApp(ZabanamozApp(authNotifier: authNotifier));
}

/// برای بازسازی Router هنگام ورود/خروج کاربر
class AuthNotifier extends ChangeNotifier {
  bool _loggedIn = false;
  bool get loggedIn => _loggedIn;
  void refresh() {
    final newLoggedIn = sb.auth.currentSession != null;
    if (newLoggedIn != _loggedIn) {
      _loggedIn = newLoggedIn;
      notifyListeners();
      router.refresh();
    }
  }
}

class ZabanamozApp extends StatelessWidget {
  const ZabanamozApp({super.key, required this.authNotifier});
  final AuthNotifier authNotifier;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: authNotifier,
      child: MaterialApp.router(
        title: 'زبان‌آموز',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light(),
        darkTheme: AppTheme.dark(),
        themeMode: ThemeMode.system,
        locale: const Locale('fa'),
        supportedLocales: const [Locale('fa'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        routerConfig: router,
      ),
    );
  }
}
