/// مدل‌های داده اپ زبان‌آموز (مطابق اسکیمای دیتابیس)

class Course {
  final int id;
  final String title;
  final String description;
  final int level; // 1=مقدماتی 2=متوسط 3=پیشرفته
  final int orderIndex;
  final bool isPublished;
  final DateTime? createdAt;

  Course({
    required this.id,
    required this.title,
    required this.description,
    required this.level,
    required this.orderIndex,
    required this.isPublished,
    this.createdAt,
  });

  factory Course.fromJson(Map<String, dynamic> j) => Course(
        id: j['id'] as int,
        title: (j['title'] ?? '') as String,
        description: (j['description'] ?? '') as String,
        level: (j['level'] ?? 1) as int,
        orderIndex: (j['order_index'] ?? 0) as int,
        isPublished: (j['is_published'] ?? false) as bool,
        createdAt: j['created_at'] == null ? null : DateTime.parse(j['created_at']),
      );

  String get levelName => switch (level) { 1 => 'مقدماتی', 2 => 'متوسط', _ => 'پیشرفته' };
}

class Lesson {
  final int id;
  final int courseId;
  final String title;
  final String content;
  final String? videoUrl;
  final int orderIndex;
  final bool isPublished;

  Lesson({
    required this.id,
    required this.courseId,
    required this.title,
    required this.content,
    required this.orderIndex,
    required this.isPublished,
    this.videoUrl,
  });

  factory Lesson.fromJson(Map<String, dynamic> j) => Lesson(
        id: j['id'] as int,
        courseId: j['course_id'] as int,
        title: (j['title'] ?? '') as String,
        content: (j['content'] ?? '') as String,
        orderIndex: (j['order_index'] ?? 0) as int,
        isPublished: (j['is_published'] ?? false) as bool,
        videoUrl: j['video_url'] as String?,
      );
}

class GrammarLesson {
  final int id;
  final String title;
  final String content;
  final String? category;
  final int orderIndex;
  final bool isPublished;

  GrammarLesson({
    required this.id,
    required this.title,
    required this.content,
    required this.orderIndex,
    required this.isPublished,
    this.category,
  });

  factory GrammarLesson.fromJson(Map<String, dynamic> j) => GrammarLesson(
        id: j['id'] as int,
        title: (j['title'] ?? '') as String,
        content: (j['content'] ?? '') as String,
        category: j['category'] as String?,
        orderIndex: (j['order_index'] ?? 0) as int,
        isPublished: (j['is_published'] ?? false) as bool,
      );
}

class Quiz {
  final int id;
  final int lessonId;
  final String title;
  final String? description;

  Quiz({required this.id, required this.lessonId, required this.title, this.description});

  factory Quiz.fromJson(Map<String, dynamic> j) => Quiz(
        id: j['id'] as int,
        lessonId: j['lesson_id'] as int,
        title: (j['title'] ?? '') as String,
        description: j['description'] as String?,
      );
}

class QuizQuestion {
  final int id;
  final int quizId;
  final String question;
  final List<String> options;
  final int correctIndex;
  final int orderIndex;
  final String? explanation;

  QuizQuestion({
    required this.id,
    required this.quizId,
    required this.question,
    required this.options,
    required this.correctIndex,
    required this.orderIndex,
    this.explanation,
  });

  factory QuizQuestion.fromJson(Map<String, dynamic> j) => QuizQuestion(
        id: j['id'] as int,
        quizId: j['quiz_id'] as int,
        question: (j['question'] ?? '') as String,
        options: (j['options'] as List).cast<String>(),
        correctIndex: (j['correct_index'] ?? 0) as int,
        orderIndex: (j['order_index'] ?? 0) as int,
        explanation: j['explanation'] as String?,
      );
}

class QuizResult {
  final int id;
  final int quizId;
  final int score;
  final int total;
  final DateTime createdAt;

  QuizResult({
    required this.id,
    required this.quizId,
    required this.score,
    required this.total,
    required this.createdAt,
  });

  factory QuizResult.fromJson(Map<String, dynamic> j) => QuizResult(
        id: j['id'] as int,
        quizId: j['quiz_id'] as int,
        score: (j['score'] ?? 0) as int,
        total: (j['total'] ?? 0) as int,
        createdAt: DateTime.parse(j['created_at']),
      );

  double get percent => total == 0 ? 0 : score / total;
}

class UserProgress {
  final int lessonId;
  final bool completed;
  final DateTime? updatedAt;

  UserProgress({required this.lessonId, required this.completed, this.updatedAt});

  factory UserProgress.fromJson(Map<String, dynamic> j) => UserProgress(
        lessonId: j['lesson_id'] as int,
        completed: (j['completed'] ?? false) as bool,
        updatedAt: j['updated_at'] == null ? null : DateTime.parse(j['updated_at']),
      );
}

class Profile {
  final String id;
  final String email;
  final String? fullName;
  final String? avatarUrl;
  final bool isBlocked;

  Profile({
    required this.id,
    required this.email,
    required this.isBlocked,
    this.fullName,
    this.avatarUrl,
  });

  factory Profile.fromJson(Map<String, dynamic> j) => Profile(
        id: j['id'] as String,
        email: (j['email'] ?? '') as String,
        fullName: j['full_name'] as String?,
        avatarUrl: j['avatar_url'] as String?,
        isBlocked: (j['is_blocked'] ?? false) as bool,
      );
}
