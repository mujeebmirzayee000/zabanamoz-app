class AppConstants {
  static const String appName = 'زبان‌آموز';
  static const String appTagline = 'انگلیسی را قدم‌به‌قدم یاد بگیر';
}
