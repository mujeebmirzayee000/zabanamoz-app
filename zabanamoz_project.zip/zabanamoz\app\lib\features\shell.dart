import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// قالب اصلی با نوار ناوبری پایین ۵ تایی (RTL)
class AppShell extends StatelessWidget {
  const AppShell({super.key, required this.child});
  final Widget child;

  static const _tabs = [
    ('/', 'خانه', Icons.home_rounded),
    ('/courses', 'دوره‌ها', Icons.menu_book_rounded),
    ('/grammar', 'گرامر', Icons.rule_rounded),
    ('/videos', 'ویدیوها', Icons.play_circle_rounded),
    ('/profile', 'پروفایل', Icons.person_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    final loc = GoRouterState.of(context).matchedLocation;
    int index = _tabs.indexWhere((t) => loc.startsWith(t.$1));
    if (index < 0) index = 0;

    return Scaffold(
      body: child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => context.go(_tabs[i].$1),
        destinations: [
          for (final t in _tabs)
            NavigationDestination(icon: Icon(t.$3), label: t.$2),
        ],
      ),
    );
  }
}
