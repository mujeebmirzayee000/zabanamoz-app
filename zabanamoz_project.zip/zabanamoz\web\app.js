/* ==========================================================================
   زبان‌آموز | ZabanAmooz — هسته اپلیکیشن
   بخش ۱: ابزارها، هش، ذخیره‌سازی، احراز هویت، لاگ زنجیره‌ای، مسیریابی، پوسته
   ========================================================================== */
(function () {
  'use strict';

  var DB_KEY = 'za_db_v2';
  var SESSION_KEY = 'za_session_v2';
  var THEME_KEY = 'za_theme_v2';

  /* ------------------------------- ابزارها ------------------------------- */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function faNum(n) { return String(n == null ? '' : n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[+d]; }); }
  function nowISO() { return new Date().toISOString(); }
  function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }
  function pct(a, b) { return b ? Math.round((a / b) * 100) : 0; }
  function uid(p) { return (p || 'id') + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4); }
  function arr(x) { return Array.isArray(x) ? x : []; }

  function faDate(iso, withTime) {
    if (!iso) return '—';
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '—';
    var out;
    try {
      out = d.toLocaleDateString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' });
      if (withTime) out += ' • ' + d.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      out = d.toISOString().slice(0, 10);
    }
    return out;
  }

  function relTime(iso) {
    var diff = Date.now() - new Date(iso).getTime();
    if (isNaN(diff)) return '—';
    var m = Math.round(diff / 60000);
    if (m < 1) return 'همین حالا';
    if (m < 60) return faNum(m) + ' دقیقه پیش';
    var h = Math.round(m / 60);
    if (h < 24) return faNum(h) + ' ساعت پیش';
    var d = Math.round(h / 24);
    if (d < 30) return faNum(d) + ' روز پیش';
    return faDate(iso);
  }

  function dayKey(d) {
    var x = new Date(d);
    return x.getFullYear() + '-' + (x.getMonth() + 1) + '-' + x.getDate();
  }

  /* --------------------------------- هش --------------------------------- */
  var _K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ];

  function rotr(x, n) { return (x >>> n) | (x << (32 - n)); }

  function sha256(str) {
    var msg = unescape(encodeURIComponent(String(str)));
    var l = msg.length;
    var blocks = Math.ceil((l + 9) / 64);
    var bytes = new Uint8Array(blocks * 64);
    var i;
    for (i = 0; i < l; i++) bytes[i] = msg.charCodeAt(i) & 0xff;
    bytes[l] = 0x80;
    var dv = new DataView(bytes.buffer);
    dv.setUint32(blocks * 64 - 8, Math.floor(l * 8 / 4294967296));
    dv.setUint32(blocks * 64 - 4, (l * 8) >>> 0);

    var h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a;
    var h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19;
    var w = new Uint32Array(64);

    for (var b = 0; b < blocks; b++) {
      var off = b * 64;
      for (i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4);
      for (i = 16; i < 64; i++) {
        var s0 = (rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3)) >>> 0;
        var s1 = (rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10)) >>> 0;
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
      }
      var a = h0, bb = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
      for (i = 0; i < 64; i++) {
        var S1 = (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) >>> 0;
        var ch = ((e & f) ^ (~e & g)) >>> 0;
        var t1 = (h + S1 + ch + _K[i] + w[i]) >>> 0;
        var S0 = (rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) >>> 0;
        var maj = ((a & bb) ^ (a & c) ^ (bb & c)) >>> 0;
        var t2 = (S0 + maj) >>> 0;
        h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = bb; bb = a; a = (t1 + t2) >>> 0;
      }
      h0 = (h0 + a) >>> 0; h1 = (h1 + bb) >>> 0; h2 = (h2 + c) >>> 0; h3 = (h3 + d) >>> 0;
      h4 = (h4 + e) >>> 0; h5 = (h5 + f) >>> 0; h6 = (h6 + g) >>> 0; h7 = (h7 + h) >>> 0;
    }
    return [h0, h1, h2, h3, h4, h5, h6, h7].map(function (x) {
      return ('00000000' + x.toString(16)).slice(-8);
    }).join('');
  }

  function hashPass(pass, salt) {
    var h = salt + '|' + pass;
    for (var i = 0; i < 900; i++) h = sha256(h);
    return h;
  }

  /* ------------------------------ رندر متن ------------------------------ */
  function md(text) {
    var lines = String(text || '').replace(/\r/g, '').split('\n');
    var out = [], inList = false, inQuote = false;

    function closeList() { if (inList) { out.push('</ul>'); inList = false; } }
    function closeQuote() { if (inQuote) { out.push('</blockquote>'); inQuote = false; } }
    function closeAll() { closeList(); closeQuote(); }
    function inline(s) {
      s = esc(s);
      s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
      s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
      s = s.replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
      return s;
    }

    lines.forEach(function (raw) {
      var line = raw.trim(), m;
      if (!line) { closeAll(); return; }
      if ((m = line.match(/^###\s+(.*)$/))) { closeAll(); out.push('<h4>' + inline(m[1]) + '</h4>'); return; }
      if ((m = line.match(/^##\s+(.*)$/))) { closeAll(); out.push('<h3>' + inline(m[1]) + '</h3>'); return; }
      if ((m = line.match(/^#\s+(.*)$/))) { closeAll(); out.push('<h2>' + inline(m[1]) + '</h2>'); return; }
      if ((m = line.match(/^[-*]\s+(.*)$/))) {
        if (!inList) { closeQuote(); out.push('<ul>'); inList = true; }
        out.push('<li>' + inline(m[1]) + '</li>');
        return;
      }
      if ((m = line.match(/^>\s?(.*)$/))) {
        if (!inQuote) { closeList(); out.push('<blockquote>'); inQuote = true; }
        out.push('<p>' + inline(m[1]) + '</p>');
        return;
      }
      closeAll();
      out.push('<p>' + inline(line) + '</p>');
    });
    closeAll();
    return out.join('\n');
  }

  /* -------------------------------- آیکون -------------------------------- */
  var ICONS = {
    home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9 21v-6h6v6"/>',
    book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M20 18v3H6.5A2.5 2.5 0 0 1 4 18.5"/>',
    layers: '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/>',
    headphones: '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><path d="M4 14h3v6H5.5A1.5 1.5 0 0 1 4 18.5z"/><path d="M20 14h-3v6h1.5a1.5 1.5 0 0 0 1.5-1.5z"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6.5 8-6.5s8 2.5 8 6.5"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 3-5.5 6.5-5.5s6.5 2 6.5 5.5"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8"/><path d="M18 14.5c2.2.6 3.5 2.1 3.5 4.5"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    moon: '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4"/>',
    check: '<path d="m4 12.5 5 5L20 6.5"/>',
    'check-circle': '<circle cx="12" cy="12" r="9"/><path d="m8 12 2.5 2.5L16 9"/>',
    play: '<path d="M8 5.5v13l11-6.5z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    volume: '<path d="M4 10v4h3l4 3.5v-11L7 10z"/><path d="M15 9a4 4 0 0 1 0 6"/><path d="M17.5 6.5a7.5 7.5 0 0 1 0 11"/>',
    lock: '<rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m3.5 7 8.5 6 8.5-6"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/>',
    shield: '<path d="M12 3 5 6v5.5c0 4.4 3 7.6 7 9.5 4-1.9 7-5.1 7-9.5V6z"/><path d="m9 12 2 2 4-4"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/><path d="m14 6 4 4"/>',
    trash: '<path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/><path d="M10 11v6M14 11v6"/>',
    eye: '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    download: '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M4 21h16"/>',
    upload: '<path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M4 21h16"/>',
    logout: '<path d="M14 4h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4"/><path d="M9 12h11"/><path d="m13 8 4 4-4 4"/>',
    x: '<path d="M6 6l12 12M18 6 6 18"/>',
    alert: '<path d="M12 3 2.5 20h19z"/><path d="M12 9v5"/><circle cx="12" cy="17.3" r=".6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><circle cx="12" cy="7.7" r=".6"/>',
    'chevron-left': '<path d="m14 6-6 6 6 6"/>',
    'chevron-right': '<path d="m10 6 6 6-6 6"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    award: '<circle cx="12" cy="9" r="5.5"/><path d="m8.5 14-1.5 7 5-2.5 5 2.5-1.5-7"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/>',
    chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    save: '<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v6h8V3"/><path d="M8 15h8"/>',
    refresh: '<path d="M20 11a8 8 0 1 0-2 6"/><path d="M20 4v7h-7"/>',
    star: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2-5.5-2.9L6.5 20l1-6.2L3 9.6l6.2-.9z"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1.2"/><circle cx="3.5" cy="12" r="1.2"/><circle cx="3.5" cy="18" r="1.2"/>',
    arrow: '<path d="M20 12H4"/><path d="m10 6-6 6 6 6"/>'
  };

  function icon(name, size, cls) {
    var p = ICONS[name] || ICONS.info;
    return '<svg class="ic ' + (cls || '') + '" width="' + (size || 18) + '" height="' + (size || 18) +
      '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' + p + '</svg>';
  }

  /* ------------------------------ اعلان کوچک ------------------------------ */
  var toastTimer = null;
  function toast(msg, type) {
    var host = $('#toastHost');
    if (!host) return;
    host.innerHTML = '<div class="toast ' + (type || 'ok') + '">' + icon(type === 'err' ? 'alert' : 'check-circle', 18) + '<span>' + esc(msg) + '</span></div>';
    host.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { host.classList.remove('on'); }, 3200);
  }

  /* ------------------------------ ذخیره‌سازی ------------------------------ */
  var DB = null;

  function defaultSettings() {
    return {
      siteName: 'زبان‌آموز',
      tagline: 'انگلیسی را قدم‌به‌قدم، با تمرین و تکرار یاد بگیر',
      primary: '#2563eb',
      allowRegister: true,
      guestBrowse: true,
      dailyGoal: 2
    };
  }

  function blankDB() {
    return {
      version: 2,
      createdAt: nowISO(),
      users: [],
      courses: [],
      grammar: [],
      listening: [],
      vocabExtra: [],
      progress: [],
      attempts: [],
      logs: [],
      settings: defaultSettings()
    };
  }

  function save() {
    try { localStorage.setItem(DB_KEY, JSON.stringify(DB)); }
    catch (e) { toast('ذخیره‌سازی ناموفق بود؛ فضای مرورگر پر است', 'err'); }
  }

  function fromSeed() {
    var seed = window.ZA_SEED || {};
    var db = blankDB();
    var salt = 'seed-' + (seed.courses ? seed.courses.length : 0);

    arr(seed.courses).forEach(function (c, ci) {
      var course = {
        id: 'c' + (c.n || ci + 1),
        n: c.n || ci + 1,
        title: c.title || ('دوره ' + (ci + 1)),
        description: c.description || '',
        level: c.level || 1,
        color: c.color || 'blue',
        lessons: []
      };
      arr(c.lessons).forEach(function (l, li) {
        course.lessons.push({
          id: course.id + 'l' + (li + 1),
          title: l.title || ('درس ' + (li + 1)),
          content: l.content || '',
          vocabulary: arr(l.vocabulary).map(function (v) {
            return { en: v.en || '', fa: v.fa || '', ipa: v.ipa || '' };
          }),
          quiz: arr(l.quiz).map(function (q) {
            return { q: q.q || '', options: arr(q.options).slice(0, 4), answer: typeof q.answer === 'number' ? q.answer : 0, why: q.why || '' };
          })
        });
      });
      db.courses.push(course);
    });

    arr(seed.grammar).forEach(function (g, gi) {
      db.grammar.push({
        id: 'g' + (g.n || gi + 1),
        n: g.n || gi + 1,
        title: g.title || ('گرامر ' + (gi + 1)),
        level: g.level || 1,
        category: g.category || 'عمومی',
        description: g.description || '',
        content: g.content || '',
        examples: g.examples || ''
      });
    });

    arr(seed.listening).forEach(function (l, li) {
      db.listening.push({
        id: 'h' + (l.n || li + 1),
        n: l.n || li + 1,
        title: l.title || ('شنیداری ' + (li + 1)),
        level: l.level || 1,
        description: l.description || '',
        lines: arr(l.lines).map(function (x) { return { s: x.s || '', t: x.t || '' }; }),
        questions: arr(l.questions).map(function (q) {
          return { q: q.q || '', options: arr(q.options).slice(0, 4), answer: typeof q.answer === 'number' ? q.answer : 0, why: q.why || '' };
        })
      });
    });

    db.vocabExtra = arr(seed.vocabExtra).map(function (v) {
      return { en: v.en || '', fa: v.fa || '', ipa: v.ipa || '' };
    });

    var p = 'Admin@1234';
    db.users.push({
      id: uid('u'),
      name: 'مدیر سیستم',
      email: 'admin@zabanamoz.ir',
      salt: salt,
      hash: hashPass(p, salt),
      role: 'admin',
      createdAt: nowISO(),
      active: true
    });

    DB = db;
    log('seed', 'داده‌های اولیه بارگذاری شد: ' + db.courses.length + ' دوره، ' + db.grammar.length + ' درس گرامر، ' + db.listening.length + ' تمرین شنیداری');
    save();
  }

  function load() {
    var raw = null;
    try { raw = localStorage.getItem(DB_KEY); } catch (e) { raw = null; }
    if (raw) {
      try {
        var parsed = JSON.parse(raw);
        if (parsed && parsed.version === 2 && Array.isArray(parsed.courses)) DB = parsed;
      } catch (e) { DB = null; }
    }
    if (!DB) { fromSeed(); return; }
    var d = defaultSettings();
    Object.keys(d).forEach(function (k) { if (DB.settings[k] === undefined) DB.settings[k] = d[k]; });
    DB.users = arr(DB.users); DB.progress = arr(DB.progress); DB.attempts = arr(DB.attempts); DB.logs = arr(DB.logs);
  }

  /* ---------------------------- لاگ زنجیره‌ای ---------------------------- */
  function actorLabel() {
    var u = currentUser();
    return u ? u.email : 'مهمان';
  }

  function log(action, detail) {
    var prev = DB.logs.length ? DB.logs[DB.logs.length - 1].hash : 'GENESIS';
    var entry = {
      i: DB.logs.length + 1,
      at: nowISO(),
      actor: actorLabel(),
      action: String(action || ''),
      detail: String(detail || '').slice(0, 300),
      prev: prev
    };
    entry.hash = sha256(JSON.stringify(entry));
    DB.logs.push(entry);
    if (DB.logs.length > 4000) DB.logs.splice(0, DB.logs.length - 4000);
  }

  function verifyChain() {
    var prev = 'GENESIS';
    var list = DB.logs;
    var startIdx = 0;
    if (list.length && list[0].prev !== 'GENESIS') { startIdx = 0; prev = list[0].prev || 'GENESIS'; }
    for (var i = startIdx; i < list.length; i++) {
      var e = list[i];
      var copy = { i: e.i, at: e.at, actor: e.actor, action: e.action, detail: e.detail, prev: e.prev };
      var h = sha256(JSON.stringify(copy));
      if (h !== e.hash) return { ok: false, broken: i + 1, reason: 'محتوای رکورد ' + faNum(i + 1) + ' با هش ثبت‌شده هم‌خوان نیست' };
      if (i > 0 && e.prev !== list[i - 1].hash) return { ok: false, broken: i + 1, reason: 'پیوند رکورد ' + faNum(i + 1) + ' به رکورد قبلی گسسته است' };
    }
    return { ok: true, count: list.length };
  }

  /* ---------------------------- احراز هویت ---------------------------- */
  function currentUser() {
    var id = null;
    try { id = localStorage.getItem(SESSION_KEY); } catch (e) { return null; }
    if (!id) return null;
    for (var i = 0; i < DB.users.length; i++) {
      if (DB.users[i].id === id) {
        if (DB.users[i].active === false) return null;
        return DB.users[i];
      }
    }
    return null;
  }

  function isAdmin() { var u = currentUser(); return !!u && u.role === 'admin'; }

  function register(name, email, pass) {
    name = String(name || '').trim();
    email = String(email || '').trim().toLowerCase();
    if (name.length < 3) return { ok: false, msg: 'نام باید حداقل ۳ نویسه باشد' };
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { ok: false, msg: 'ایمیل معتبر نیست' };
    if (String(pass || '').length < 8) return { ok: false, msg: 'گذرواژه باید حداقل ۸ نویسه باشد' };
    if (!DB.settings.allowRegister) return { ok: false, msg: 'ثبت‌نام توسط مدیر غیرفعال شده است' };
    if (DB.users.some(function (u) { return u.email === email; })) return { ok: false, msg: 'این ایمیل قبلاً ثبت شده است' };
    var salt = uid('s');
    var user = {
      id: uid('u'), name: name, email: email, salt: salt, hash: hashPass(pass, salt),
      role: 'student', createdAt: nowISO(), active: true
    };
    DB.users.push(user);
    try { localStorage.setItem(SESSION_KEY, user.id); } catch (e) { }
    log('auth.register', 'ثبت‌نام کاربر ' + email);
    save();
    return { ok: true, user: user };
  }

  function login(email, pass) {
    email = String(email || '').trim().toLowerCase();
    var user = DB.users.filter(function (u) { return u.email === email; })[0];
    if (!user) return { ok: false, msg: 'کاربری با این ایمیل یافت نشد' };
    if (user.active === false) return { ok: false, msg: 'حساب شما غیرفعال شده است' };
    if (hashPass(pass, user.salt) !== user.hash) return { ok: false, msg: 'گذرواژه نادرست است' };
    try { localStorage.setItem(SESSION_KEY, user.id); } catch (e) { }
    log('auth.login', 'ورود کاربر ' + email);
    save();
    return { ok: true, user: user };
  }

  function logout() {
    var u = currentUser();
    if (u) { log('auth.logout', 'خروج کاربر ' + u.email); save(); }
    try { localStorage.removeItem(SESSION_KEY); } catch (e) { }
  }

  /* ------------------------------ پیشرفت ------------------------------ */
  function myProgress() {
    var u = currentUser();
    if (!u) return [];
    return DB.progress.filter(function (p) { return p.userId === u.id; });
  }

  function lessonState(lessonId) {
    var p = myProgress().filter(function (x) { return x.lessonId === lessonId; })[0];
    return p || null;
  }

  function allLessons() {
    var out = [];
    DB.courses.forEach(function (c) {
      c.lessons.forEach(function (l) { out.push({ course: c, lesson: l }); });
    });
    return out;
  }

  function findCourse(id) { return DB.courses.filter(function (c) { return c.id === id; })[0] || null; }
  function findLesson(lessonId) {
    var all = allLessons();
    for (var i = 0; i < all.length; i++) if (all[i].lesson.id === lessonId) return all[i];
    return null;
  }
  function findGrammar(id) { return DB.grammar.filter(function (g) { return g.id === id; })[0] || null; }
  function findListening(id) { return DB.listening.filter(function (x) { return x.id === id; })[0] || null; }

  function recordAttempt(kind, refId, score, total) {
    var u = currentUser();
    if (!u) return;
    DB.attempts.push({ id: uid('a'), userId: u.id, kind: kind, refId: refId, score: score, total: total, at: nowISO() });
    if (DB.attempts.length > 3000) DB.attempts.splice(0, DB.attempts.length - 3000);
  }

  function completeLesson(lesson, score, total) {
    var u = currentUser();
    if (!u) return { guest: true };
    var p = DB.progress.filter(function (x) { return x.userId === u.id && x.lessonId === lesson.id; })[0];
    if (!p) {
      p = { userId: u.id, lessonId: lesson.id, score: 0, total: 0, completed: false, at: nowISO(), updatedAt: nowISO() };
      DB.progress.push(p);
    }
    var ratio = total ? score / total : 1;
    if (total && ratio > (p.total ? p.score / p.total : 0)) { p.score = score; p.total = total; }
    if (!total) { p.completed = true; }
    else if (ratio >= 0.6) { p.completed = true; }
    p.updatedAt = nowISO();
    p.visits = (p.visits || 0) + 1;
    if (total) recordAttempt('lesson', lesson.id, score, total);
    log('lesson.done', 'درس «' + lesson.title + '» — امتیاز ' + score + '/' + total);
    save();
    return { ok: true, completed: p.completed };
  }

  function streakDays() {
    var u = currentUser();
    if (!u) return 0;
    var days = {};
    DB.attempts.filter(function (a) { return a.userId === u.id; }).forEach(function (a) { days[dayKey(a.at)] = true; });
    DB.progress.filter(function (p) { return p.userId === u.id; }).forEach(function (p) { days[dayKey(p.updatedAt || p.at)] = true; });
    var n = 0, d = new Date();
    for (var i = 0; i < 400; i++) {
      var k = dayKey(d);
      if (days[k]) { n++; d.setDate(d.getDate() - 1); }
      else if (i === 0) { d.setDate(d.getDate() - 1); }
      else break;
    }
    return n;
  }

  /* ------------------------------ مسیریابی ------------------------------ */
  var routes = [];
  function route(pattern, handler) { routes.push({ parts: pattern.split('/').filter(Boolean), handler: handler }); }

  function currentPath() {
    var h = (location.hash || '').replace(/^#/, '');
    if (!h) return '/home';
    return h.split('?')[0];
  }

  function qs() {
    var h = location.hash || '';
    var i = h.indexOf('?');
    var out = {};
    if (i < 0) return out;
    h.slice(i + 1).split('&').forEach(function (kv) {
      if (!kv) return;
      var p = kv.split('=');
      out[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || '');
    });
    return out;
  }

  function go(path) { location.hash = path; }

  function match(parts, pathParts) {
    if (parts.length !== pathParts.length) return null;
    var params = {};
    for (var i = 0; i < parts.length; i++) {
      if (parts[i].charAt(0) === ':') params[parts[i].slice(1)] = decodeURIComponent(pathParts[i]);
      else if (parts[i] !== pathParts[i]) return null;
    }
    return params;
  }

  var afterRender = null;

  function render() {
    var path = currentPath();
    var pathParts = path.split('/').filter(Boolean);
    var found = null, params = {};
    for (var i = 0; i < routes.length; i++) {
      var m = match(routes[i].parts, pathParts);
      if (m) { found = routes[i]; params = m; break; }
    }
    afterRender = null;
    var html;
    if (!found) {
      html = '<div class="empty big">' + icon('alert', 40) + '<h2>صفحه پیدا نشد</h2><p>مسیر <code>#' + esc(path) + '</code> وجود ندارد.</p><a class="btn" href="#/home">بازگشت به خانه</a></div>';
      $('#app').innerHTML = shell(html);
    } else {
      try {
        var view = found.handler(params) || { html: '' };
        $('#app').innerHTML = view.shell === false ? view.html : shell(view.html, params);
        if (typeof view.after === 'function') afterRender = view.after;
      } catch (err) {
        $('#app').innerHTML = shell('<div class="alert err"><strong>خطا در نمایش صفحه</strong><pre>' + esc(err && err.message ? err.message : String(err)) + '</pre></div>');
      }
    }
    window.scrollTo(0, 0);
    if (afterRender) { try { afterRender(); } catch (e) { } }
    var act = $('.nav a.active');
    if (act) act.scrollIntoView({ block: 'nearest', inline: 'center' });
  }

  /* ------------------------------- پوسته ------------------------------- */
  var NAV = [
    { p: '/home', t: 'خانه', i: 'home' },
    { p: '/courses', t: 'دوره‌ها', i: 'book' },
    { p: '/grammar', t: 'گرامر', i: 'layers' },
    { p: '/listening', t: 'شنیداری', i: 'headphones' },
    { p: '/vocab', t: 'واژه‌ها', i: 'star' },
    { p: '/progress', t: 'پیشرفت', i: 'chart' }
  ];

  function shell(html, params) {
    var u = currentUser();
    var st = DB.settings;
    var path = currentPath();
    var admin = isAdmin();

    var nav = NAV.map(function (n) {
      var active = path === n.p || (n.p !== '/home' && path.indexOf(n.p) === 0) ? ' class="active"' : '';
      return '<a href="#' + n.p + '"' + nav_attr(n.p) + '>' + icon(n.i, 18) + '<span>' + n.t + '</span></a>';
    }).join('');
    function nav_attr() { return ''; }

    var navHtml = NAV.map(function (n) {
      var active = path === n.p || (n.p !== '/home' && path.indexOf(n.p) === 0);
      return '<a href="#' + n.p + '"' + (active ? ' class="active"' : '') + '>' + icon(n.i, 18) + '<span>' + n.t + '</span></a>';
    }).join('');

    var themeBtn = '<button class="icon-btn" data-act="theme" title="تغییر پوسته">' + icon(document.documentElement.getAttribute('data-theme') === 'dark' ? 'sun' : 'moon', 18) + '</button>';

    var userBox;
    if (u) {
      userBox = '<a class="chip" href="#/profile" title="پروفایل">' +
        '<span class="avatar">' + esc(u.name.trim().charAt(0)) + '</span>' +
        '<span class="chip-name">' + esc(u.name) + '</span></a>' +
        (admin ? '<a class="icon-btn" href="#/admin" title="پنل مدیریت">' + icon('shield', 18) + '</a>' : '');
    } else {
      userBox = '<a class="btn sm" href="#/login">ورود</a><a class="btn sm ghost" href="#/register">ثبت‌نام</a>';
    }

    return '' +
      '<header class="topbar">' +
      '<div class="topbar-in">' +
      '<a class="brand" href="#/home"><span class="logo">' + icon('book', 20) + '</span><span class="brand-txt">' + esc(st.siteName) + '<small>یادگیری انگلیسی</small></span></a>' +
      '<nav class="nav">' + navHtml + '</nav>' +
      '<div class="tools">' +
      '<a class="icon-btn" href="#/search" title="جست‌وجو">' + icon('search', 18) + '</a>' + themeBtn + userBox +
      '</div>' +
      '</div>' +
      '</header>' +
      '<main class="wrap">' + html + '</main>' +
      '<nav class="tabbar">' + navHtml + '</nav>' +
      '<footer class="foot">' + esc(st.siteName) + ' — ساخته‌شده برای تمرین روزانه زبان انگلیسی <span class="dot">•</span> نسخه ۲.۰</footer>';
  }

  /* ------------------------------ خروجی موتور ------------------------------ */
  window.ZA = {
    /* ابزار */
    $: $, $$: $$, esc: esc, faNum: faNum, faDate: faDate, relTime: relTime, md: md, icon: icon, toast: toast,
    pct: pct, uid: uid, clamp: clamp, arr: arr, nowISO: nowISO, sha256: sha256, hashPass: hashPass, dayKey: dayKey,
    speak: speak,
    /* داده */
    get db() { return DB; },
    save: save, settings: function () { return DB.settings; }, defaultSettings: defaultSettings,
    findCourse: findCourse, findLesson: findLesson, findGrammar: findGrammar, findListening: findListening,
    allLessons: allLessons, myProgress: myProgress, lessonState: lessonState, completeLesson: completeLesson,
    recordAttempt: recordAttempt, streakDays: streakDays,
    /* هویت */
    user: currentUser, isAdmin: isAdmin, login: login, register: register, logout: logout,
    /* لاگ */
    log: log, verifyChain: verifyChain,
    /* مسیر */
    route: route, go: go, render: render, qs: qs, path: currentPath, shell: shell,
    /* داخلی برای بخش‌های بعدی */
    setAfter: function (fn) { afterRender = fn; }
  };

  /* ------------------------------- گفتار ------------------------------- */
  function speak(text, rate, onend) {
    try {
      if (!('speechSynthesis' in window)) { toast('مرورگر شما از پخش صوتی پشتیبانی نمی‌کند', 'err'); return null; }
      window.speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(String(text));
      u.lang = 'en-US';
      u.rate = rate || 0.92;
      var voices = window.speechSynthesis.getVoices() || [];
      var pick = null;
      for (var i = 0; i < voices.length; i++) {
        if (/^en[-_]US/i.test(voices[i].lang)) { pick = voices[i]; break; }
        if (!pick && /^en/i.test(voices[i].lang)) pick = voices[i];
      }
      if (pick) u.voice = pick;
      if (typeof onend === 'function') u.onend = onend;
      window.speechSynthesis.speak(u);
      return u;
    } catch (e) { return null; }
  }

  /* ------------------------------- راه‌اندازی ------------------------------- */
  function boot() {
    var theme = 'light';
    try { theme = localStorage.getItem(THEME_KEY) || 'light'; } catch (e) { }
    document.documentElement.setAttribute('data-theme', theme);
    load();
    applyPrimary();
    window.ZA.routesLoaded = true;
  }

  function applyPrimary() {
    var c = DB.settings.primary || '#2563eb';
    document.documentElement.style.setProperty('--primary', c);
    document.documentElement.style.setProperty('--primary-soft', hexMix(c, 0.12));
  }

  function hexMix(hex, alpha) {
    var m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    if (!m) return 'rgba(37,99,235,' + alpha + ')';
    return 'rgba(' + parseInt(m[1], 16) + ',' + parseInt(m[2], 16) + ',' + parseInt(m[3], 16) + ',' + alpha + ')';
  }

  window.ZA.applyPrimary = applyPrimary;
  window.ZA.boot = boot;

  /* رخدادهای سراسری */
  document.addEventListener('click', function (ev) {
    var el = ev.target.closest ? ev.target.closest('[data-act]') : null;
    if (!el) return;
    var act = el.getAttribute('data-act');
    if (act === 'theme') {
      ev.preventDefault();
      var cur = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', cur);
      try { localStorage.setItem(THEME_KEY, cur); } catch (e) { }
      render();
      return;
    }
    if (act === 'logout') {
      ev.preventDefault();
      logout();
      toast('از حساب خارج شدید');
      go('/home');
      return;
    }
    if (window.ZA.onAct) window.ZA.onAct(act, el, ev);
  });

  window.addEventListener('hashchange', function () { if (window.ZA.viewsReady) render(); });
  document.addEventListener('DOMContentLoaded', function () {
    boot();
    if (window.ZA.viewsReady) render();
  });
})();
