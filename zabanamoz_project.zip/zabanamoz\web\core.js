/* ============================================================
   زبان‌آموز — هسته برنامه
   ذخیره‌سازی محلی، احراز هویت، نقش‌ها، مسیریابی، چیدمان و ابزارها
   ============================================================ */
(function () {
  'use strict';

  /* ---------------- ابزارهای عمومی ---------------- */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  const esc = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  const attr = esc;

  const uid = () => {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  };

  const nowISO = () => new Date().toISOString();
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const faNum = (n) => String(n == null ? '' : n).replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d]);
  const pct = (a, b) => (b ? Math.round((a / b) * 100) : 0);

  function faDate(iso, withTime) {
    if (!iso) return '—';
    try {
      const d = new Date(iso);
      const opts = { year: 'numeric', month: 'long', day: 'numeric' };
      if (withTime) { opts.hour = '2-digit'; opts.minute = '2-digit'; }
      return new Intl.DateTimeFormat('fa-IR', opts).format(d);
    } catch (e) { return iso.slice(0, 10); }
  }

  function relTime(iso) {
    if (!iso) return '';
    try {
      const diff = Date.now() - new Date(iso).getTime();
      const min = Math.round(diff / 60000);
      if (min < 1) return 'همین حالا';
      if (min < 60) return faNum(min) + ' دقیقه پیش';
      const h = Math.round(min / 60);
      if (h < 24) return faNum(h) + ' ساعت پیش';
      const d = Math.round(h / 24);
      if (d < 30) return faNum(d) + ' روز پیش';
      return faDate(iso);
    } catch (e) { return ''; }
  }

  function dayKey(d) {
    const x = new Date(d);
    return x.getFullYear() + '-' + String(x.getMonth() + 1).padStart(2, '0') + '-' + String(x.getDate()).padStart(2, '0');
  }

  function timeAgoDays(d) {
    return Math.floor((Date.now() - new Date(d).getTime()) / 86400000);
  }

  /* ---------------- آیکون‌ها ---------------- */
  const P = {
    home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9 21v-6h6v6"/>',
    book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M20 18v3H6.5A2.5 2.5 0 0 1 4 18.5"/>',
    layers: '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/>',
    headphones: '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><path d="M4 14h3v6H5.5A1.5 1.5 0 0 1 4 18.5z"/><path d="M20 14h-3v6h1.5a1.5 1.5 0 0 0 1.5-1.5z"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6.5 8-6.5s8 2.5 8 6.5"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 3-5.5 6.5-5.5s6.5 2 6.5 5.5"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8"/><path d="M18 14.5c2.2.6 3.5 2.1 3.5 4.5"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    moon: '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4"/>',
    check: '<path d="m4 12.5 5 5L20 6.5"/>',
    'check-circle': '<circle cx="12" cy="12" r="9"/><path d="m8 12 2.5 2.5L16 9"/>',
    play: '<path d="M8 5.5v13l11-6.5z"/>',
    volume: '<path d="M4 10v4h3l4 3.5v-11L7 10z"/><path d="M15 9a4 4 0 0 1 0 6"/><path d="M17.5 6.5a7.5 7.5 0 0 1 0 11"/>',
    lock: '<rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m3.5 7 8.5 6 8.5-6"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/>',
    shield: '<path d="M12 3 5 6v5.5c0 4.4 3 7.6 7 9.5 4-1.9 7-5.1 7-9.5V6z"/><path d="m9 12 2 2 4-4"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/><path d="m14 6 4 4"/>',
    trash: '<path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/><path d="M10 11v6M14 11v6"/>',
    eye: '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    'eye-off': '<path d="m3 3 18 18"/><path d="M10.6 6.2A10.6 10.6 0 0 1 12 6c6.4 0 10 6 10 6a17 17 0 0 1-3.2 3.9M6.6 6.7A16.6 16.6 0 0 0 2 12s3.6 6 10 6a10 10 0 0 0 4-.8"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
    download: '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M4 21h16"/>',
    upload: '<path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M4 21h16"/>',
    logout: '<path d="M14 4h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4"/><path d="M9 12h11"/><path d="m13 8 4 4-4 4"/>',
    x: '<path d="M6 6l12 12M18 6 6 18"/>',
    alert: '<path d="M12 3 2.5 20h19z"/><path d="M12 9v5"/><circle cx="12" cy="17.3" r=".6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><circle cx="12" cy="7.7" r=".6"/>',
    'chevron-left': '<path d="m14 6-6 6 6 6"/>',
    'chevron-right': '<path d="m10 6 6 6-6 6"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    award: '<circle cx="12" cy="9" r="5.5"/><path d="m8.5 14-1.5 7 5-2.5 5 2.5-1.5-7"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/>',
    chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    save: '<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v6h8V3"/><path d="M8 15h8"/>',
    refresh: '<path d="M20 11a8 8 0 1 0-2 6"/><path d="M20 4v7h-7"/>',
    star: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2-5.5-2.9L6.5 20l1-6.2L3 9.6l6.2-.9z"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a15 15 0 0 1 0 18 15 15 0 0 1 0-18Z"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9"/><path d="m17 6 3 3"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    arrowup: '<path d="M12 20V5"/><path d="m6 11 6-6 6 6"/>',
    sparkle: '<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16l.9 2.1L22 19l-2.1.9L19 22l-.9-2.1L16 19l2.1-.9z"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
    brain: '<path d="M9.5 4a3 3 0 0 0-3 3 3 3 0 0 0-1 5.8V16a3 3 0 0 0 4 2.8V20h1.5V5.5A1.5 1.5 0 0 0 9.5 4Z"/><path d="M14.5 4a3 3 0 0 1 3 3 3 3 0 0 1 1 5.8V16a3 3 0 0 1-4 2.8V20h-1.5V5.5A1.5 1.5 0 0 1 14.5 4Z"/>',
    filter: '<path d="M3 5h18l-7 8v6l-4 2v-8z"/>'
  };

  function icon(name, cls) {
    const path = P[name] || P.info;
    return '<svg class="' + (cls || '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + path + '</svg>';
  }

  /* ---------------- SHA-256 و هش رمز ---------------- */
  function utf8Binary(str) {
    const bytes = new TextEncoder().encode(str);
    let out = '';
    const CH = 0x8000;
    for (let i = 0; i < bytes.length; i += CH) {
      out += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    }
    return out;
  }

  function sha256(ascii) {
    const rightRotate = (v, a) => (v >>> a) | (v << (32 - a));
    const maxWord = Math.pow(2, 32);
    let result = '';
    const words = [];
    const asciiBitLength = ascii.length * 8;
    let hash = sha256.h = sha256.h || [];
    let k = sha256.k = sha256.k || [];
    let primeCounter = k.length;
    const isComposite = {};
    for (let candidate = 2; primeCounter < 64; candidate++) {
      if (!isComposite[candidate]) {
        for (let i = 0; i < 313; i += candidate) isComposite[i] = candidate;
        hash[primeCounter] = (Math.pow(candidate, 0.5) * maxWord) | 0;
        k[primeCounter++] = (Math.pow(candidate, 1 / 3) * maxWord) | 0;
      }
    }
    ascii += '\x80';
    while (ascii.length % 64 - 56) ascii += '\x00';
    for (let i = 0; i < ascii.length; i++) {
      const j = ascii.charCodeAt(i);
      if (j >> 8) return '';
      words[i >> 2] |= j << ((3 - i) % 4) * 8;
    }
    words[words.length] = (asciiBitLength / 8 / Math.pow(2, 32)) | 0;
    words[words.length] = asciiBitLength;
    for (let j = 0; j < words.length;) {
      const w = words.slice(j, j += 16);
      const oldHash = hash;
      hash = hash.slice(0, 8);
      for (let i = 0; i < 64; i++) {
        const w15 = w[i - 15];
        const w2 = w[i - 2];
        const a = hash[0];
        const e = hash[4];
        const t1 = hash[7] + (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25)) +
          ((e & hash[5]) ^ ((~e) & hash[6])) + k[i] +
          (w[i] = (i < 16) ? w[i] : (w[i - 16] + (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3)) + w[i - 7] + (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))) | 0);
        const t2 = (rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22)) + ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
        hash = [(t1 + t2) | 0].concat(hash);
        hash[4] = (hash[4] + t1) | 0;
      }
      for (let i = 0; i < 8; i++) hash[i] = (hash[i] + oldHash[i]) | 0;
    }
    for (let i = 0; i < 8; i++) {
      for (let j = 3; j + 1; j--) {
        const b = (hash[i] >> (j * 8)) & 255;
        result += ((b < 16) ? '0' : '') + b.toString(16);
      }
    }
    return result;
  }

  function toB64(buf) {
    const bytes = new Uint8Array(buf);
    let s = '';
    for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    return btoa(s);
  }

  async function makePassword(pw) {
    const salt = toB64(crypto.getRandomValues(new Uint8Array(16)));
    if (window.crypto && crypto.subtle) {
      try {
        const enc = new TextEncoder();
        const key = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
        const bits = await crypto.subtle.deriveBits(
          { name: 'PBKDF2', salt: enc.encode(salt), iterations: 120000, hash: 'SHA-256' }, key, 256);
        return { algo: 'pbkdf2', iter: 120000, salt: salt, hash: toB64(bits) };
      } catch (e) { /* fallback */ }
    }
    let h = utf8Binary(salt + ':' + pw);
    for (let i = 0; i < 900; i++) h = sha256(utf8Binary(h + ':' + i));
    return { algo: 'sha256', iter: 900, salt: salt, hash: h };
  }

  async function checkPassword(pw, rec) {
    if (!rec) return false;
    if (rec.algo === 'pbkdf2' && window.crypto && crypto.subtle) {
      try {
        const enc = new TextEncoder();
        const key = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
        const bits = await crypto.subtle.deriveBits(
          { name: 'PBKDF2', salt: enc.encode(rec.salt), iterations: rec.iter || 120000, hash: 'SHA-256' }, key, 256);
        return toB64(bits) === rec.hash;
      } catch (e) { return false; }
    }
    let h = utf8Binary((rec.salt || '') + ':' + pw);
    for (let i = 0; i < (rec.iter || 900); i++) h = sha256(utf8Binary(h + ':' + i));
    return h === rec.hash;
  }

  /* ---------------- ذخیره‌سازی ---------------- */
  const DB_KEY = 'zabanamoz.db.v1';
  const SESSION_KEY = 'zabanamoz.session.v1';
  const THEME_KEY = 'zabanamoz.theme';

  function emptyDB() {
    return {
      version: 1,
      settings: {
        appName: 'زبان‌آموز',
        tagline: 'انگلیسی را قدم‌به‌قدم یاد بگیر',
        ownerCreated: false,
        demo: false,
        createdAt: nowISO()
      },
      users: [],
      courses: [],
      lessons: [],
      grammar_lessons: [],
      quizzes: [],
      quiz_questions: [],
      quiz_results: [],
      user_progress: [],
      listening_lessons: [],
      word_progress: [],
      audit_log: []
    };
  }

  function seedDatabase(db) {
    const seed = window.ZA_SEED;
    const mk = seed.mk;
    let ci = 0;

    seed.courses.forEach((c, courseIndex) => {
      ci++;
      const courseId = mk('c0000000', ci);
      db.courses.push({
        id: courseId,
        title: c.title,
        description: c.description,
        level: c.level,
        color: c.color,
        image_url: '',
        sort_order: courseIndex + 1,
        is_published: true,
        created_at: nowISO()
      });

      c.lessons.forEach((l, li) => {
        const lessonId = mk('e0000000', ci * 100 + li + 1);
        db.lessons.push({
          id: lessonId,
          course_id: courseId,
          title: l.title,
          content: l.content,
          video_url: l.video_url || '',
          vocabulary: l.vocabulary || [],
          sort_order: li + 1,
          is_published: true,
          created_at: nowISO()
        });

        if (l.quiz && l.quiz.length) {
          const quizId = mk('d0000000', ci * 100 + li + 1);
          db.quizzes.push({ id: quizId, lesson_id: lessonId, created_at: nowISO() });
          l.quiz.forEach((q, qi) => {
            db.quiz_questions.push({
              id: mk('f0000000', ci * 10000 + (li + 1) * 100 + qi + 1),
              quiz_id: quizId,
              question: q.q,
              options: q.options.slice(),
              correct_index: q.answer,
              explanation: q.why || '',
              sort_order: qi + 1
            });
          });
        }
      });
    });

    seed.grammar.forEach((g, i) => {
      db.grammar_lessons.push({
        id: mk('a0000000', i + 1),
        title: g.title,
        category: g.category || 'عمومی',
        content: g.content,
        examples: g.examples,
        sort_order: i + 1,
        is_published: true,
        created_at: nowISO()
      });
    });

    seed.listening.forEach((s, i) => {
      db.listening_lessons.push({
        id: mk('b0000000', i + 1),
        title: s.title,
        description: s.description,
        level: s.level || 1,
        lines: s.lines,
        questions: s.questions || [],
        sort_order: i + 1,
        is_published: true,
        created_at: nowISO()
      });
    });

    db.word_progress = [];
    return db;
  }

  const DB = {
    load() {
      let db = null;
      try {
        const raw = localStorage.getItem(DB_KEY);
        if (raw) db = JSON.parse(raw);
      } catch (e) { db = null; }
      if (!db || typeof db !== 'object') {
        db = seedDatabase(emptyDB());
        this.save(db);
      }
      const base = emptyDB();
      for (const k in base) if (db[k] === undefined) db[k] = base[k];
      if (!db.settings) db.settings = base.settings;
      return db;
    },
    save(db) {
      try {
        localStorage.setItem(DB_KEY, JSON.stringify(db));
        return true;
      } catch (e) {
        UI.toast('ذخیره‌سازی ناموفق بود؛ فضای مرورگر پر است.', 'error');
        return false;
      }
    },
    reset() {
      localStorage.removeItem(DB_KEY);
      localStorage.removeItem(SESSION_KEY);
    }
  };

  /* ---------------- نشست و کاربر ---------------- */
  const Auth = {
    session() {
      try {
        const raw = localStorage.getItem(SESSION_KEY);
        if (!raw) return null;
        const s = JSON.parse(raw);
        const user = App.db.users.find((u) => u.id === s.userId);
        if (!user || user.is_blocked) return null;
        return s;
      } catch (e) { return null; }
    },
    user() {
      const s = this.session();
      if (!s) return null;
      return App.db.users.find((u) => u.id === s.userId) || null;
    },
    login(email, password) {
      const e = String(email || '').trim().toLowerCase();
      const user = App.db.users.find((u) => u.email.toLowerCase() === e);
      if (!user) return { ok: false, msg: 'ایمیل یا رمز عبور درست نیست.' };
      if (user.is_blocked) return { ok: false, msg: 'این حساب مسدود شده است. با پشتیبانی تماس بگیرید.' };
      return checkPassword(password, user.pass).then((ok) => {
        if (!ok) return { ok: false, msg: 'ایمیل یا رمز عبور درست نیست.' };
        localStorage.setItem(SESSION_KEY, JSON.stringify({ userId: user.id, at: nowISO() }));
        user.last_seen_at = nowISO();
        DB.save(App.db);
        App.audit('login_success', { email: user.email });
        return { ok: true };
      });
    },
    async register(name, email, password) {
      const e = String(email || '').trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) return { ok: false, msg: 'ایمیل معتبر وارد کنید.' };
      if (App.db.users.some((u) => u.email.toLowerCase() === e)) return { ok: false, msg: 'این ایمیل قبلاً ثبت شده است.' };
      if (String(password).length < 8) return { ok: false, msg: 'رمز عبور باید حداقل ۸ کاراکتر باشد.' };
      const pass = await makePassword(password);
      const u = {
        id: uid(), email: e, name: String(name || '').trim() || 'زبان‌آموز',
        pass, role: 'student', is_blocked: false, isDemo: false,
        created_at: nowISO(), last_seen_at: nowISO()
      };
      App.db.users.push(u);
      DB.save(App.db);
      App.audit('register', { email: e });
      return { ok: true, user: u };
    },
    async createOwner(name, email, password) {
      if (App.db.users.some((u) => u.role === 'owner')) return { ok: false, msg: 'حساب مالک قبلاً ساخته شده است.' };
      const e = String(email || '').trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) return { ok: false, msg: 'ایمیل معتبر وارد کنید.' };
      if (App.db.users.some((u) => u.email.toLowerCase() === e)) return { ok: false, msg: 'این ایمیل قبلاً ثبت شده است.' };
      if (String(password).length < 8) return { ok: false, msg: 'رمز عبور باید حداقل ۸ کاراکتر باشد.' };
      const pass = await makePassword(password);
      const u = {
        id: uid(), email: e, name: String(name || '').trim() || 'مدیر',
        pass, role: 'owner', is_blocked: false, isDemo: false,
        created_at: nowISO(), last_seen_at: nowISO()
      };
      App.db.users.push(u);
      App.db.settings.ownerCreated = true;
      DB.save(App.db);
      App.audit('owner_setup', { email: e });
      return { ok: true, user: u };
    },
    async changePassword(userId, newPassword) {
      if (String(newPassword).length < 8) return { ok: false, msg: 'رمز جدید باید حداقل ۸ کاراکتر باشد.' };
      const u = App.db.users.find((x) => x.id === userId);
      if (!u) return { ok: false, msg: 'کاربر پیدا نشد.' };
      u.pass = await makePassword(newPassword);
      u.pass_changed_at = nowISO();
      DB.save(App.db);
      App.audit('password_change', { email: u.email });
      return { ok: true };
    },
    logout() {
      const u = this.user();
      if (u) App.audit('logout', { email: u.email });
      localStorage.removeItem(SESSION_KEY);
      App.render();
      location.hash = '#/login';
    },
    isOwner() {
      const u = this.user();
      return !!u && u.role === 'owner';
    }
  };

  /* ---------------- لاگ امنیتی زنجیره‌ای ---------------- */
  function audit(eventType, details) {
    const db = App.db;
    if (!db) return;
    const prev = db.audit_log.length ? db.audit_log[db.audit_log.length - 1].row_hash : 'GENESIS';
    const user = Auth.user();
    const stamp = nowISO();
    const payload = prev + '|' + eventType + '|' + (user ? user.id : '') + '|' + JSON.stringify(details || {}) + '|' + stamp;
    const row = {
      id: db.audit_log.length + 1,
      event_type: eventType,
      user_id: user ? user.id : null,
      details: details || {},
      prev_hash: prev,
      row_hash: sha256(utf8Binary(payload)),
      created_at: stamp
    };
    db.audit_log.push(row);
    if (db.audit_log.length > 600) db.audit_log.shift();
    DB.save(db);
  }

  /* ---------------- متن و مارک‌داون ---------------- */
  function inlineMd(s) {
    return s
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  }

  function markdown(text) {
    const src = String(text || '').replace(/\r\n/g, '\n');
    const lines = src.split('\n');
    let out = '';
    let list = null;
    const closeList = () => { if (list) { out += '</' + list + '>'; list = null; } };
    lines.forEach((raw) => {
      const line = raw.trim();
      if (!line) { closeList(); return; }
      if (/^###\s+/.test(line)) { closeList(); out += '<h3>' + inlineMd(esc(line.replace(/^###\s+/, ''))) + '</h3>'; return; }
      if (/^##\s+/.test(line)) { closeList(); out += '<h2>' + inlineMd(esc(line.replace(/^##\s+/, ''))) + '</h2>'; return; }
      if (/^#\s+/.test(line)) { closeList(); out += '<h2>' + inlineMd(esc(line.replace(/^#\s+/, ''))) + '</h2>'; return; }
      if (/^>\s?/.test(line)) { closeList(); out += '<blockquote>' + inlineMd(esc(line.replace(/^>\s?/, ''))) + '</blockquote>'; return; }
      const ul = line.match(/^[-*]\s+(.*)$/);
      const ol = line.match(/^\d+[.)]\s+(.*)$/);
      if (ul) {
        if (list !== 'ul') { closeList(); out += '<ul>'; list = 'ul'; }
        out += '<li>' + inlineMd(esc(ul[1])) + '</li>';
        return;
      }
      if (ol) {
        if (list !== 'ol') { closeList(); out += '<ol>'; list = 'ol'; }
        out += '<li>' + inlineMd(esc(ol[1])) + '</li>';
        return;
      }
      closeList();
      out += '<p>' + inlineMd(esc(line)) + '</p>';
    });
    closeList();
    return out;
  }

  /* ---------------- متن به گفتار ---------------- */
  const TTS = {
    supported: 'speechSynthesis' in window,
    _voice: null,
    voice() {
      if (!this.supported) return null;
      if (this._voice) return this._voice;
      const voices = speechSynthesis.getVoices() || [];
      this._voice = voices.find((v) => /^en[-_](US|GB)/i.test(v.lang)) || voices.find((v) => /^en/i.test(v.lang)) || null;
      return this._voice;
    },
    speak(text, opts) {
      if (!this.supported) { UI.toast('مرورگر شما از خواندن صوتی پشتیبانی نمی‌کند.', 'error'); return; }
      const o = opts || {};
      try {
        speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(String(text || ''));
        u.lang = 'en-US';
        u.rate = o.rate || 0.92;
        u.pitch = 1;
        const v = this.voice();
        if (v) { u.voice = v; u.lang = v.lang; }
        if (o.onend) u.onend = o.onend;
        if (o.onstart) u.onstart = o.onstart;
        speechSynthesis.speak(u);
      } catch (e) {
        UI.toast('پخش صدا ممکن نشد.', 'error');
      }
    },
    stop() { if (this.supported) speechSynthesis.cancel(); }
  };

  /* ---------------- رابط کاربری عمومی ---------------- */
  const UI = {
    toast(msg, type, ms) {
      let wrap = $('.toast-wrap');
      if (!wrap) {
        wrap = document.createElement('div');
        wrap.className = 'toast-wrap';
        document.body.appendChild(wrap);
      }
      const el = document.createElement('div');
      el.className = 'toast ' + (type || '');
      el.innerHTML = icon(type === 'error' ? 'alert' : type === 'ok' ? 'check-circle' : 'info') + '<span>' + esc(msg) + '</span>';
      wrap.appendChild(el);
      setTimeout(() => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(8px)';
        el.style.transition = 'all .25s';
        setTimeout(() => el.remove(), 260);
      }, ms || 3400);
    },

    modal(opts) {
      const wrap = document.createElement('div');
      wrap.className = 'overlay';
      const actions = (opts.actions || []).map((a, i) =>
        '<button class="btn ' + (a.kind || 'ghost') + '" data-i="' + i + '">' + (a.icon ? icon(a.icon) : '') + esc(a.label) + '</button>'
      ).join('');
      wrap.innerHTML =
        '<div class="modal" role="dialog" aria-modal="true">' +
          '<div class="modal-head"><h3>' + esc(opts.title || '') + '</h3>' +
            '<button class="icon-btn" data-close style="margin-inline-start:auto;width:34px;height:34px">' + icon('x') + '</button></div>' +
          '<div class="modal-body">' + (opts.body || '') + '</div>' +
          (actions ? '<div class="modal-foot">' + actions + '</div>' : '') +
        '</div>';
      document.body.appendChild(wrap);
      const close = () => { wrap.remove(); };
      wrap.addEventListener('click', (e) => {
        if (e.target === wrap || e.target.closest('[data-close]')) close();
      });
      (opts.actions || []).forEach((a, i) => {
        const btn = wrap.querySelector('[data-i="' + i + '"]');
        if (btn) btn.addEventListener('click', () => { if (!a.onClick || a.onClick(wrap, close) !== false) close(); });
      });
      if (opts.onMount) opts.onMount(wrap, close);
      return { close: close, el: wrap };
    },

    confirm(opts) {
      return new Promise((resolve) => {
        UI.modal({
          title: opts.title || 'تأیید',
          body: '<p style="margin:0;line-height:1.9">' + esc(opts.body || '') + '</p>',
          actions: [
            { label: opts.cancel || 'انصراف', kind: 'ghost', onClick: () => resolve(false) },
            { label: opts.ok || 'تأیید', kind: opts.danger ? 'danger-solid' : 'primary', onClick: () => resolve(true) }
          ]
        });
      });
    }
  };

  /* ---------------- تنظیم تم ---------------- */
  const Theme = {
    get() { return localStorage.getItem(THEME_KEY) || 'light'; },
    set(v) {
      localStorage.setItem(THEME_KEY, v);
      document.documentElement.setAttribute('data-theme', v);
    },
    toggle() {
      this.set(this.get() === 'dark' ? 'light' : 'dark');
      App.render();
    },
    apply() { document.documentElement.setAttribute('data-theme', this.get()); }
  };

  /* ---------------- داده‌های مشترک ---------------- */
  const Data = {
    courses(publishedOnly) {
      const list = App.db.courses.slice().sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
      return publishedOnly === false ? list : list.filter((c) => c.is_published);
    },
    lessons(courseId, publishedOnly) {
      let list = App.db.lessons.filter((l) => !courseId || l.course_id === courseId);
      list.sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
      if (publishedOnly !== false) list = list.filter((l) => l.is_published);
      return list;
    },
    lesson(id) { return App.db.lessons.find((l) => l.id === id); },
    course(id) { return App.db.courses.find((c) => c.id === id); },
    grammar(id) { return App.db.grammar_lessons.find((g) => g.id === id); },
    listening(id) { return App.db.listening_lessons.find((s) => s.id === id); },
    quizForLesson(lessonId) { return App.db.quizzes.find((q) => q.lesson_id === lessonId); },
    questions(quizId) {
      return App.db.quiz_questions.filter((q) => q.quiz_id === quizId)
        .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
    },
    progress(userId) {
      return App.db.user_progress.filter((p) => p.user_id === userId);
    },
    completedIds(userId) {
      return new Set(App.db.user_progress.filter((p) => p.user_id === userId).map((p) => p.lesson_id));
    },
    results(userId) {
      return App.db.quiz_results.filter((r) => r.user_id === userId)
        .sort((a, b) => new Date(b.taken_at) - new Date(a.taken_at));
    },
    courseProgress(courseId, userId) {
      const lessons = this.lessons(courseId, false).filter((l) => l.is_published);
      const done = this.completedIds(userId);
      const n = lessons.filter((l) => done.has(l.id)).length;
      return { done: n, total: lessons.length, percent: pct(n, lessons.length) };
    },
    allProgress(userId) {
      const lessons = App.db.lessons.filter((l) => l.is_published);
      const done = this.completedIds(userId);
      const n = lessons.filter((l) => done.has(l.id)).length;
      return { done: n, total: lessons.length, percent: pct(n, lessons.length) };
    },
    vocab(userId) {
      const out = [];
      App.db.lessons.filter((l) => l.is_published).forEach((l) => {
        (l.vocabulary || []).forEach((v) => out.push(Object.assign({ lessonId: l.id }, v)));
      });
      (window.ZA_SEED.vocabExtra || []).forEach((v) => out.push(Object.assign({ lessonId: null }, v)));
      const seen = new Set();
      return out.filter((v) => {
        const k = v.en.toLowerCase();
        if (seen.has(k)) return false;
        seen.add(k);
        return true;
      });
    },
    wordState(userId, word) {
      return App.db.word_progress.find((w) => w.user_id === userId && w.word === word) || null;
    },
    streak(userId) {
      const stamps = new Set();
      this.progress(userId).forEach((p) => { if (p.completed_at) stamps.add(dayKey(p.completed_at)); });
      this.results(userId).forEach((r) => { if (r.taken_at) stamps.add(dayKey(r.taken_at)); });
      let streak = 0;
      const d = new Date();
      for (;;) {
        if (stamps.has(dayKey(d))) { streak++; d.setDate(d.getDate() - 1); }
        else if (streak === 0) {
          d.setDate(d.getDate() - 1);
          if (!stamps.has(dayKey(d))) break;
        } else break;
      }
      return streak;
    },
    weekly(userId) {
      const days = [];
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const k = dayKey(d);
        const n = this.progress(userId).filter((p) => p.completed_at && dayKey(p.completed_at) === k).length;
        days.push({ key: k, date: d, count: n });
      }
      return days;
    }
  };

  /* ---------------- مسیریابی ---------------- */
  const TITLES = {
    '/': 'خانه', '/courses': 'دوره‌ها', '/grammar': 'گرامر', '/listening': 'شنیداری',
    '/vocab': 'واژه‌ها', '/progress': 'پیشرفت من', '/profile': 'پروفایل', '/search': 'جستجو',
    '/admin': 'پنل مدیریت', '/admin/courses': 'مدیریت دوره‌ها', '/admin/lessons': 'مدیریت درس‌ها',
    '/admin/grammar': 'مدیریت گرامر', '/admin/users': 'کاربران', '/admin/audit': 'لاگ امنیتی',
    '/admin/settings': 'تنظیمات'
  };

  const NAV = [
    { p: '/', t: 'خانه', i: 'home' },
    { p: '/courses', t: 'دوره‌ها', i: 'book' },
    { p: '/grammar', t: 'گرامر', i: 'layers' },
    { p: '/listening', t: 'شنیداری', i: 'headphones' },
    { p: '/vocab', t: 'واژه‌ها', i: 'brain' },
    { p: '/progress', t: 'پیشرفت من', i: 'chart' }
  ];

  const ADMIN_NAV = [
    { p: '/admin', t: 'داشبورد', i: 'grid' },
    { p: '/admin/courses', t: 'دوره‌ها', i: 'book' },
    { p: '/admin/lessons', t: 'درس‌ها', i: 'list' },
    { p: '/admin/grammar', t: 'گرامر', i: 'layers' },
    { p: '/admin/users', t: 'کاربران', i: 'users' },
    { p: '/admin/audit', t: 'لاگ امنیتی', i: 'shield' },
    { p: '/admin/settings', t: 'تنظیمات', i: 'settings' }
  ];

  function parseHash() {
    let h = location.hash.replace(/^#/, '');
    if (!h) h = '/';
    const [pathPart, queryPart] = h.split('?');
    let path = pathPart || '/';
    if (!path.startsWith('/')) path = '/' + path;
    const parts = path.split('/').filter(Boolean).map(decodeURIComponent);
    const query = {};
    if (queryPart) {
      queryPart.split('&').forEach((kv) => {
        const [k, v] = kv.split('=');
        if (k) query[decodeURIComponent(k)] = decodeURIComponent(v || '');
      });
    }
    return { path: '/' + parts.join('/'), parts, query };
  }

  function go(path) {
    if (location.hash === '#' + path) { App.render(); return; }
    location.hash = '#' + path;
  }

  function activeNav(p) {
    if (p === '/') return App.route.path === '/';
    return App.route.path === p || App.route.path.startsWith(p + '/');
  }

  /* ---------------- قالب اصلی ---------------- */
  function brandBlock(sub) {
    return '<div class="brand">' +
      '<div class="brand-logo">' + icon('sparkle') + '</div>' +
      '<div><div class="brand-name">' + esc(App.db.settings.appName) + '</div>' +
      '<div class="brand-sub">' + esc(sub || App.db.settings.tagline) + '</div></div>' +
    '</div>';
  }

  function sidebar() {
    const u = App.user;
    const items = NAV.map((n) =>
      '<button class="nav-item ' + (activeNav(n.p) ? 'active' : '') + '" data-nav="' + n.p + '">' +
        icon(n.i) + '<span>' + n.t + '</span></button>'
    ).join('');
    const admin = u && u.role === 'owner' ? (
      '<div class="nav-label">مدیریت</div>' +
      ADMIN_NAV.map((n) =>
        '<button class="nav-item ' + (activeNav(n.p) ? 'active' : '') + '" data-nav="' + n.p + '">' +
          icon(n.i) + '<span>' + n.t + '</span></button>'
      ).join('')
    ) : '';
    return '<aside class="sidebar">' +
      brandBlock() +
      '<div class="nav-label">یادگیری</div>' + items +
      admin +
      '<div class="sidebar-footer">' +
        '<div class="side-user">' +
          '<div class="avatar sm">' + esc(initials(u && u.name)) + '</div>' +
          '<div class="meta grow"><div class="name">' + esc(u ? u.name : '') + '</div>' +
          '<div class="mail">' + esc(u ? u.email : '') + '</div></div>' +
          '<button class="icon-btn" style="width:32px;height:32px" title="خروج" data-a="logout">' + icon('logout') + '</button>' +
        '</div>' +
      '</div>' +
    '</aside>';
  }

  function initials(name) {
    const s = String(name || 'ز').trim();
    if (!s) return 'ز';
    const parts = s.split(/\s+/);
    if (parts.length > 1) return (parts[0][0] + parts[1][0]);
    return s.slice(0, 2);
  }

  function topbar(title) {
    return '<header class="topbar">' +
      '<div class="topbar-title">' + esc(title) + '</div>' +
      '<div class="spacer"></div>' +
      '<form class="search-mini" data-form="topsearch" role="search">' +
        icon('search') +
        '<input name="q" type="search" placeholder="جستجوی درس، گرامر یا واژه…" value="' + attr(App.route.query.q || '') + '" />' +
      '</form>' +
      '<button class="icon-btn" data-a="theme" title="تغییر تم">' + icon(Theme.get() === 'dark' ? 'sun' : 'moon') + '</button>' +
      '<button class="avatar" data-nav="/profile" title="پروفایل">' + esc(initials(App.user && App.user.name)) + '</button>' +
    '</header>';
  }

  function bottomNav() {
    const items = [
      { p: '/', t: 'خانه', i: 'home' },
      { p: '/courses', t: 'دوره‌ها', i: 'book' },
      { p: '/grammar', t: 'گرامر', i: 'layers' },
      { p: '/listening', t: 'شنیداری', i: 'headphones' },
      { p: '/profile', t: 'پروفایل', i: 'user' }
    ];
    return '<nav class="bottom-nav">' + items.map((n) =>
      '<button class="bn-item ' + (activeNav(n.p) ? 'on' : '') + '" data-nav="' + n.p + '">' +
        icon(n.i) + '<span>' + n.t + '</span></button>'
    ).join('') + '</nav>';
  }

  function authLayout(inner) {
    return '<div class="auth-wrap">' +
      '<div class="auth-art"><div class="dots"></div>' +
        '<div style="position:relative">' +
          '<div style="display:flex;align-items:center;gap:12px;margin-bottom:34px">' +
            '<div class="brand-logo" style="background:rgba(255,255,255,.18);box-shadow:none">' + icon('sparkle') + '</div>' +
            '<div><div style="font-weight:800;font-size:18px">' + esc(App.db.settings.appName) + '</div>' +
            '<div style="font-size:11.5px;opacity:.8">' + esc(App.db.settings.tagline) + '</div></div>' +
          '</div>' +
          '<h2>هر روز یک قدم<br/>به انگلیسی روان‌تر</h2>' +
          '<p>دوره‌های مرحله‌بندی‌شده، تمرین شنیداری با صدای طبیعی، کوییز و پیگیری پیشرفت — همه در یک برنامه ساده.</p>' +
        '</div>' +
        '<div class="quote">یادگیری زبان با تمرین کوتاه روزانه اتفاق می‌افتد، نه با یک شب تلاش.</div>' +
      '</div>' +
      '<div class="auth-panel"><div class="auth-box">' + inner + '</div></div>' +
    '</div>';
  }

  /* ---------------- رندر ---------------- */
  const App = {
    db: null,
    user: null,
    route: { path: '/', parts: [], query: {} },
    audit: audit,
    go: go,
    DA: { Data: Data, icon: icon, TTS: TTS, markdown: markdown, faNum: faNum, faDate: faDate, relTime: relTime, esc: esc, attr: attr, pct: pct, UI: UI, Auth: Auth, DB: DB, Theme: Theme, uid: uid, nowISO: nowISO, dkey: dayKey, initials: initials },

    boot() {
      Theme.apply();
      this.db = DB.load();
      this.handleFresh();
      this.route = parseHash();
      this.user = Auth.user();
      this.render();
      window.addEventListener('hashchange', () => {
        this.route = parseHash();
        this.user = Auth.user();
        this.render();
        window.scrollTo(0, 0);
      });
      window.addEventListener('beforeunload', () => TTS.stop());
      document.addEventListener('click', (e) => {
        const nav = e.target.closest('[data-nav]');
        if (nav) { e.preventDefault(); go(nav.getAttribute('data-nav')); return; }
      });
      document.addEventListener('submit', (e) => {
        const form = e.target.closest('[data-form="topsearch"]');
        if (form) {
          e.preventDefault();
          const q = form.querySelector('input[name="q"]').value.trim();
          go('/search?q=' + encodeURIComponent(q));
        }
      });
      document.addEventListener('click', (e) => {
        const t = e.target.closest('[data-a="theme"]');
        if (t) Theme.toggle();
      });
      document.addEventListener('click', (e) => {
        if (e.target.closest('[data-a="logout"]')) {
          UI.confirm({ title: 'خروج از حساب', body: 'از حساب کاربری خارج می‌شوید؟', ok: 'خروج', danger: true })
            .then((yes) => { if (yes) Auth.logout(); });
        }
      });
      if (window.speechSynthesis) speechSynthesis.onvoiceschanged = () => { TTS._voice = null; };
    },

    handleFresh() {
      const params = new URLSearchParams(location.search);
      const demo = params.get('demo');
      if (!demo) return;
      if (this.db.users.length) {
        // حساب‌های نمایشی که در راه‌اندازی ساخته شده‌اند
        if (demo === 'student' || demo === 'owner') {
          history.replaceState(null, '', location.pathname + location.hash);
        }
        return;
      }
      // فقط در نصب کاملاً تازه: ساخت خودکار حساب نمایشی
      const ownerEmail = 'owner@demo.local';
      const studentEmail = 'student@demo.local';
      const now = nowISO();
      this.db.users.push({
        id: uid(), email: ownerEmail, name: 'مدیر نمایشی',
        pass: null, role: 'owner', is_blocked: false, isDemo: true,
        created_at: now, last_seen_at: now
      });
      this.db.users.push({
        id: uid(), email: studentEmail, name: 'زبان‌آموز نمایشی',
        pass: null, role: 'student', is_blocked: false, isDemo: true,
        created_at: now, last_seen_at: now
      });
      this.db.settings.demo = true;
      this.db.settings.ownerCreated = true;
      DB.save(this.db);
      makePassword('Demo1234').then((p) => {
        this.db.users.forEach((u) => { if (u.isDemo) u.pass = p; });
        DB.save(this.db);
        this.autoDemoLogin(demo);
      });
    },

    async autoDemoLogin(kind) {
      const email = kind === 'owner' ? 'owner@demo.local' : 'student@demo.local';
      const u = this.db.users.find((x) => x.email === email && x.isDemo);
      if (!u) return;
      const r = await Auth.login(email, 'Demo1234');
      if (r.ok) {
        this.user = Auth.user();
        history.replaceState(null, '', location.pathname + location.hash);
        this.render();
        UI.toast(kind === 'owner' ? 'ورود نمایشی مدیر' : 'ورود نمایشی زبان‌آموز', 'ok');
      }
    },

    needAuth(path) {
      const isAuth = path === '/login' || path === '/register' || path === '/setup';
      if (!this.db.users.some((u) => u.role === 'owner')) return '/setup';
      if (!this.user && !isAuth) return '/login';
      if (this.user && isAuth) return '/';
      return null;
    },

    render() {
      const route = this.route;
      const isAuthRoute = ['/login', '/register', '/setup'].includes(route.path);
      const redirect = this.needAuth(route.path);

      if (redirect && redirect !== route.path) {
        location.replace('#' + redirect);
        return;
      }

      if (isAuthRoute) {
        const view = Views.auth(route.path);
        $('#app').innerHTML = authLayout(view.html);
        view.bind && view.bind();
        return;
      }

      if (route.path === '/admin' || route.path.startsWith('/admin/')) {
        if (!Auth.isOwner()) {
          $('#app').innerHTML = '<div class="page">' + Views.forbidden() + '</div>';
          return;
        }
      }

      const title = TITLES[route.path] || (route.parts[0] === 'lesson' ? 'درس' :
        route.parts[0] === 'course' ? 'جزئیات دوره' : route.parts[0] === 'quiz' ? 'کوییز' :
        route.parts[0] === 'grammar' ? 'گرامر' : route.parts[0] === 'listening' ? 'تمرین شنیداری' : 'زبان‌آموز');

      let view;
      try {
        view = this.resolveView(route);
      } catch (e) {
        view = { html: Views.error('خطا در نمایش صفحه: ' + e.message) };
      }

      $('#app').innerHTML =
        '<div class="app">' +
          sidebar() +
          '<div class="main">' + topbar(title) +
            '<div class="page" id="page-root">' + view.html + '</div>' +
          '</div>' + bottomNav() +
        '</div>';

      if (view.bind) {
        try { view.bind(); } catch (e) { console.warn(e); }
      }
      this.afterRender(route);
    },

    afterRender(route) {
      $$('[data-nav]').forEach((el) => {
        if (!el.dataset.bound) {
          el.dataset.bound = '1';
          el.addEventListener('click', (e) => {
            e.preventDefault();
            go(el.getAttribute('data-nav'));
          });
        }
      });
    },

    resolveView(route) {
      const p = route.parts;
      if (p.length === 0) return Views.home();
      switch (p[0]) {
        case 'courses': return p[1] ? Views.courseDetail(p[1]) : Views.courses();
        case 'course': return Views.courseDetail(p[1]);
        case 'lesson': return Views.lesson(p[1]);
        case 'quiz': return Views.quizView(p[1]);
        case 'grammar': return p[1] ? Views.grammarDetail(p[1]) : Views.grammar();
        case 'listening': return p[1] ? Views.listeningDetail(p[1]) : Views.listening();
        case 'vocab': return Views.vocab();
        case 'progress': return Views.progress();
        case 'search': return Views.search();
        case 'profile': return Views.profile();
        case 'admin': return AdminViews.route(p.slice(1), route.query);
        default: return { html: Views.notFound() };
      }
    }
  };

  /* ---------------- شروع ---------------- */
  document.addEventListener('DOMContentLoaded', () => {
    App.boot();
  });

  window.App = App;
  window.ZA = {
    $: $, $$: $$, esc: esc, attr: attr, icon: icon, faNum: faNum, faDate: faDate,
    relTime: relTime, markdown: markdown, UI: UI, Data: Data, Auth: Auth, DB: DB,
    Theme: Theme, TTS: TTS, go: go, sha256: sha256, utf8Binary: utf8Binary,
    makePassword: makePassword, checkPassword: checkPassword, initials: initials, pct: pct
  };
  window.Views = window.Views || {};
  window.AdminViews = window.AdminViews || {};
})();
