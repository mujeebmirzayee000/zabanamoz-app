import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/cache.dart';
import '../core/supabase_client.dart';
import 'models.dart';

/// لایه دسترسی به داده + کش محلی
class Repos {
  static const _prefix = 'cache_';

  // ---------- دوره‌ها ----------
  static Future<List<Course>> fetchCourses({bool refresh = false}) async {
    final key = '${_prefix}courses';
    if (!refresh) {
      final c = await LocalCache.get(key);
      if (c != null) return c.map(Course.fromJson).toList();
    }
    final rows = await sb
        .from('courses')
        .select()
        .eq('is_published', true)
        .order('order_index');
    final list = (rows as List).cast<Map<String, dynamic>>();
    await LocalCache.put(key, list);
    return list.map(Course.fromJson).toList();
  }

  // ---------- درس‌ها ----------
  static Future<List<Lesson>> fetchLessons(int courseId, {bool refresh = false}) async {
    final key = '${_prefix}lessons_$courseId';
    if (!refresh) {
      final c = await LocalCache.get(key);
      if (c != null) return c.map(Lesson.fromJson).toList();
    }
    final rows = await sb
        .from('lessons')
        .select()
        .eq('course_id', courseId)
        .eq('is_published', true)
        .order('order_index');
    final list = (rows as List).cast<Map<String, dynamic>>();
    await LocalCache.put(key, list);
    return list.map(Lesson.fromJson).toList();
  }

  // ---------- همه درس‌های ویدیویی (از ویو امن) ----------
  static Future<List<Lesson>> fetchVideoLessons({bool refresh = false}) async {
    final key = '${_prefix}video_lessons';
    if (!refresh) {
      final c = await LocalCache.get(key);
      if (c != null) return c.map(Lesson.fromJson).toList();
    }
    final rows = await sb.from('lesson_videos').select().order('order_index');
    final list = (rows as List).cast<Map<String, dynamic>>();
    await LocalCache.put(key, list);
    return list.map(Lesson.fromJson).toList();
  }

  // ---------- گرامر ----------
  static Future<List<GrammarLesson>> fetchGrammar({bool refresh = false}) async {
    final key = '${_prefix}grammar';
    if (!refresh) {
      final c = await LocalCache.get(key);
      if (c != null) return c.map(GrammarLesson.fromJson).toList();
    }
    final rows = await sb
        .from('grammar_lessons')
        .select()
        .eq('is_published', true)
        .order('order_index');
    final list = (rows as List).cast<Map<String, dynamic>>();
    await LocalCache.put(key, list);
    return list.map(GrammarLesson.fromJson).toList();
  }

  // ---------- کوییز ----------
  static Future<Quiz?> fetchQuizForLesson(int lessonId) async {
    final rows = await sb
        .from('quizzes')
        .select()
        .eq('lesson_id', lessonId)
        .limit(1);
    if ((rows as List).isEmpty) return null;
    return Quiz.fromJson((rows as List).cast<Map<String, dynamic>>().first);
  }

  static Future<List<QuizQuestion>> fetchQuestions(int quizId) async {
    final rows = await sb
        .from('quiz_questions')
        .select()
        .eq('quiz_id', quizId)
        .order('order_index');
    return (rows as List).cast<Map<String, dynamic>>().map(QuizQuestion.fromJson).toList();
  }

  static Future<void> saveQuizResult(int quizId, int score, int total) async {
    final uid = sb.auth.currentUser?.id;
    if (uid == null) return;
    await sb.from('quiz_results').insert({'user_id': uid, 'quiz_id': quizId, 'score': score, 'total': total});
  }

  // ---------- پیشرفت ----------
  static Future<List<UserProgress>> fetchProgress() async {
    final uid = sb.auth.currentUser?.id;
    if (uid == null) return [];
    final rows = await sb.from('user_progress').select().eq('user_id', uid);
    return (rows as List).cast<Map<String, dynamic>>().map(UserProgress.fromJson).toList();
  }

  static Future<void> markLessonComplete(int lessonId, bool completed) async {
    final uid = sb.auth.currentUser?.id;
    if (uid == null) return;
    await sb.from('user_progress').upsert({
      'user_id': uid,
      'lesson_id': lessonId,
      'completed': completed,
      'updated_at': DateTime.now().toIso8601String(),
    }, onConflict: 'user_id,lesson_id');
  }

  // ---------- جستجو ----------
  static Future<(List<Lesson>, List<GrammarLesson>)> search(String q) async {
    final term = '%${q.trim()}%';
    final lessonsRows = await sb.from('lessons').select().ilike('title', term).limit(30);
    final grammarRows = await sb.from('grammar_lessons').select().ilike('title', term).limit(30);
    final lessons = (lessonsRows as List).cast<Map<String, dynamic>>()
        .map(Lesson.fromJson).where((l) => l.isPublished).toList();
    final grammar = (grammarRows as List).cast<Map<String, dynamic>>()
        .map(GrammarLesson.fromJson).where((g) => g.isPublished).toList();
    return (lessons, grammar);
  }

  // ---------- پروفایل ----------
  static Future<Profile> fetchProfile() async {
    final uid = sb.auth.currentUser!.id;
    final rows = await sb.from('profiles').select().eq('id', uid).single();
    return Profile.fromJson(rows);
  }

  static Future<void> updateProfile({String? fullName}) async {
    final uid = sb.auth.currentUser!.id;
    final data = <String, dynamic>{};
    if (fullName != null) data['full_name'] = fullName;
    if (data.isNotEmpty) await sb.from('profiles').update(data).eq('id', uid);
  }

  /// آپلود آواتار به مسیر avatars/<uid>/avatar.<ext> (سیاست RLS فقط مسیر خود کاربر)
  static Future<String> uploadAvatar(String filePath) async {
    final uid = sb.auth.currentUser!.id;
    final ext = filePath.split('.').last.toLowerCase();
    final dest = '$uid/avatar.$ext';
    await sb.storage.from('avatars').upload(dest, filePath, fileOptions: const FileOptions(upsert: true));
    return sb.storage.from('avatars').getPublicUrl(dest);
  }

  // ---------- پروفایل: تغییر رمز ----------
  static Future<void> changePassword(String newPassword) async {
    await sb.auth.updateUser(UserAttributes(password: newPassword));
  }
}
