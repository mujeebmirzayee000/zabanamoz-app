$ErrorActionPreference = 'SilentlyContinue'
$candidates = @(
  'C:\flutter', 'C:\src\flutter', 'C:\tools\flutter', 'C:\flutter sdk',
  "$env:USERPROFILE\flutter", "$env:USERPROFILE\fvm",
  "$env:LOCALAPPDATA\Programs\flutter", 'D:\flutter', 'D:\dev\flutter',
  'C:\Android', "$env:LOCALAPPDATA\Android\Sdk",
  'C:\Program Files\Android\Android Studio',
  'C:\Program Files\Java', 'C:\Program Files\Eclipse Adoptium',
  'C:\Program Files\nodejs', "$env:APPDATA\npm"
)
Write-Output '=== PATH candidates ==='
foreach ($c in $candidates) {
  if (Test-Path $c) { Write-Output "EXISTS: $c" }
}
Write-Output '=== flutter/dart binaries (depth-limited scan) ==='
$roots = @('C:\Users\SMC', 'C:\Program Files', 'C:\ProgramData', 'D:\dev')
foreach ($r in $roots) {
  Get-ChildItem -Path $r -Filter 'flutter.bat' -Recurse -Depth 4 -File -ErrorAction SilentlyContinue |
    Select-Object -First 5 | ForEach-Object { Write-Output "FLUTTER: $($_.FullName)" }
  Get-ChildItem -Path $r -Filter 'dart.exe' -Recurse -Depth 4 -File -ErrorAction SilentlyContinue |
    Select-Object -First 5 | ForEach-Object { Write-Output "DART: $($_.FullName)" }
}
Write-Output '=== commands ==='
foreach ($cmd in @('flutter','dart','java','node','npm','python','py','git','adb','chrome','msedge')) {
  $p = (Get-Command $cmd -ErrorAction SilentlyContinue).Source
  if ($p) { Write-Output "CMD $cmd -> $p" }
}
Write-Output '=== browsers ==='
$browsers = @(
  'C:\Program Files\Google\Chrome\Application\chrome.exe',
  'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
  'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
  'C:\Program Files\Microsoft\Edge\Application\msedge.exe'
)
foreach ($b in $browsers) { if (Test-Path $b) { Write-Output "BROWSER: $b" } }
Write-Output '=== dotnet / powershell ==='
Write-Output ("PSVersion: " + $PSVersionTable.PSVersion.ToString())
Write-Output '=== disk ==='
Get-PSDrive -PSProvider FileSystem | ForEach-Object { Write-Output ("DRIVE {0}: free={1}GB" -f $_.Name, [math]::Round($_.Free/1GB,1)) }
