import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// کش ساده محلی برای کار در اینترنت ضعیف (فهرست‌ها تا ۱۲ ساعت معتبرند)
class LocalCache {
  static const Duration _ttl = Duration(hours: 12);

  static Future<void> put(String key, List<Map<String, dynamic>> rows) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(key, jsonEncode({
      't': DateTime.now().millisecondsSinceEpoch,
      'd': rows,
    }));
  }

  static Future<List<Map<String, dynamic>>?> get(String key) async {
    try {
      final sp = await SharedPreferences.getInstance();
      final raw = sp.getString(key);
      if (raw == null) return null;
      final obj = jsonDecode(raw) as Map<String, dynamic>;
      final t = obj['t'] as int;
      final age = DateTime.now().millisecondsSinceEpoch - t;
      if (age > _ttl.inMilliseconds) return null;
      return (obj['d'] as List).cast<Map<String, dynamic>>();
    } catch (_) {
      return null;
    }
  }

  static Future<void> clear() async {
    final sp = await SharedPreferences.getInstance();
    for (final k in sp.getKeys()) {
      if (k.startsWith('cache_')) await sp.remove(k);
    }
  }
}
