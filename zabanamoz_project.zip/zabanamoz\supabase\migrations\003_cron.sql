-- ============================================================================
-- زبان‌آموز — Migration 003: هشدار ایمیلی زمان‌بندی‌شده (pg_cron + pg_net)
-- ----------------------------------------------------------------------------
-- پیش‌نیاز (یک‌بار در Dashboard فعال کن):
--   Database → Extensions → "pg_cron" و "pg_net" → Enable
-- سپس این فایل را در SQL Editor اجرا کن.
-- ----------------------------------------------------------------------------

create extension if not exists pg_cron;
create extension if not exists pg_net;

-- ============================================================================
-- ۱) تابع ارسال هشدارها به Edge Function (alert-email)
-- ============================================================================
create or replace function public.fn_notify_alerts()
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_url  text;
  v_key  text;
  v_rows jsonb;
  v_ids  bigint[];
begin
  -- اسرار را مالک در app_secrets ذخیره کرده (پایین فایل راهنما هست)
  select value into v_url from public.app_secrets where key = 'ALERT_FUNCTION_URL';
  select value into v_key from public.app_secrets where key = 'ALERT_SERVICE_KEY';
  if v_url is null or v_key is null or v_url = '' or v_key = '' then
    return; -- تا وقتی اسرار تنظیم نشده، کاری نکن
  end if;

  -- رویدادهای امنیتی هنوز ایمیل‌نشده
  with alert_rows as (
    select id, jsonb_build_object(
             'id', id,
             'event_type', event_type,
             'created_at', created_at,
             'details', details
           ) as payload
    from public.audit_log
    where emailed = false
      and event_type in (
        'admin_auto_lock',
        'break_glass_used',
        'break_glass_failed',
        'role_tamper_attempt',
        'owner_profile_delete_attempt',
        'profile_block_tamper_attempt',
        'quiz_result_spoof_attempt',
        'owner_created'
      )
    order by id
    for update skip locked
  )
  select coalesce(jsonb_agg(payload), '[]'::jsonb), array_agg(id)
    into v_rows, v_ids
    from alert_rows;

  if v_ids is null or array_length(v_ids, 1) = 0 then
    return;
  end if;

  -- ارسال (pg_net ناهمگام است)
  perform net.http_post(
    url     := v_url,
    headers := jsonb_build_object(
                 'Content-Type', 'application/json',
                 'Authorization', 'Bearer ' || v_key
               ),
    body    := jsonb_build_object('alerts', v_rows)
  );

  -- علامت‌گذاری «ایمیل شد» (best-effort؛ رویدادها همچنان در audit_log می‌مانند)
  update public.audit_log
     set emailed = true
   where id = any(v_ids);
end;
$$;

revoke execute on function public.fn_notify_alerts() from public, anon, authenticated;

-- ============================================================================
-- ۲) زمان‌بندی: هر ۱۰ دقیقه یک‌بار
-- ============================================================================
do $$
begin
  if exists (select 1 from cron.job where jobname = 'zabanamoz_alerts') then
    perform cron.unschedule('zabanamoz_alerts');
  end if;
  perform cron.schedule(
    'zabanamoz_alerts',
    '*/10 * * * *',
    $$select public.fn_notify_alerts();$$
  );
end;
$$;

-- ============================================================================
-- راهنمای تنظیم اسرار (بعد از دیپلوی Edge Function این دو را اجرا کن):
--
--   insert into public.app_secrets(key, value) values
--     ('ALERT_FUNCTION_URL', 'https://jgkxhnsaunqbylfvlfwh.supabase.co/functions/v1/alert-email'),
--     ('ALERT_SERVICE_KEY',  '«کلید service_role پروژه»')
--   on conflict (key) do update set value = excluded.value, updated_at = now();
--
-- ایمیل مقصد هشدارها هم در همان جدول با کلید ALERT_EMAIL_TO ذخیره می‌شود
-- (توسط Edge Function خوانده می‌شود):
--
--   insert into public.app_secrets(key, value) values
--     ('ALERT_EMAIL_TO', 'ایمیل-خودت@example.com')
--   on conflict (key) do update set value = excluded.value, updated_at = now();
-- ============================================================================
