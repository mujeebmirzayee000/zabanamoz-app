import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'core/supabase_client.dart';
import 'features/auth_screens.dart';
import 'features/shell.dart';
import 'features/home.dart';
import 'features/courses_screens.dart';
import 'features/grammar_screens.dart';
import 'features/videos_screens.dart';
import 'features/profile_screen.dart';
import 'features/quiz_screen.dart';
import 'features/progress_screen.dart';
import 'features/search_screen.dart';

final _rootNav = GlobalKey<NavigatorState>();

final router = GoRouter(
  navigatorKey: _rootNav,
  initialLocation: '/',
  redirect: (context, state) {
    final session = sb.auth.currentSession;
    final loggingIn = state.matchedLocation.startsWith('/login') ||
        state.matchedLocation.startsWith('/register') ||
        state.matchedLocation.startsWith('/forgot');
    if (session == null) return loggingIn ? null : '/login';
    if (loggingIn) return '/';
    return null;
  },
  routes: [
    GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
    GoRoute(path: '/register', builder: (_, __) => const RegisterScreen()),
    GoRoute(path: '/forgot', builder: (_, __) => const ForgotPasswordScreen()),
    ShellRoute(
      builder: (context, state, child) => AppShell(child: child),
      routes: [
        GoRoute(
          path: '/',
          pageBuilder: (_, __) => const NoTransitionPage(child: HomeScreen()),
        ),
        GoRoute(
          path: '/courses',
          pageBuilder: (_, __) => const NoTransitionPage(child: CoursesScreen()),
          routes: [
            GoRoute(
              path: ':id',
              builder: (_, s) =>
                  CourseDetailScreen(courseId: int.parse(s.pathParameters['id']!)),
            ),
          ],
        ),
        GoRoute(
          path: '/grammar',
          pageBuilder: (_, __) => const NoTransitionPage(child: GrammarScreen()),
          routes: [
            GoRoute(
              path: ':id',
              builder: (_, s) =>
                  GrammarDetailScreen(id: int.parse(s.pathParameters['id']!)),
            ),
          ],
        ),
        GoRoute(
          path: '/videos',
          pageBuilder: (_, __) => const NoTransitionPage(child: VideosScreen()),
          routes: [
            GoRoute(
              path: ':id',
              builder: (_, s) => VideoPlayerScreen(lessonId: int.parse(s.pathParameters['id']!)),
            ),
          ],
        ),
        GoRoute(
          path: '/profile',
          pageBuilder: (_, __) => const NoTransitionPage(child: ProfileScreen()),
        ),
      ],
    ),
    GoRoute(path: '/lesson/:id', builder: (_, s) => LessonDetailScreen(id: int.parse(s.pathParameters['id']!))),
    GoRoute(path: '/quiz/:lessonId', builder: (_, s) => QuizScreen(lessonId: int.parse(s.pathParameters['lessonId']!))),
    GoRoute(path: '/progress', builder: (_, __) => const ProgressScreen()),
    GoRoute(path: '/search', builder: (_, __) => const SearchScreen()),
  ],
);
