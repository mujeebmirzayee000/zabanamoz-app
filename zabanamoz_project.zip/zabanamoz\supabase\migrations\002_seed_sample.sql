-- ============================================================================
-- زبان‌آموز — Migration 002: داده نمونه (اختیاری ولی پیشنهادشده)
-- اجرا: بعد از 001_init.sql در SQL Editor
-- این داده‌ها نمونه هستند؛ بعداً از پنل ادمین ویرایش/حذفشان کن.
-- ============================================================================

-- ---------- دوره ۱: مقدماتی ----------
insert into public.courses (title, description, sort_order)
values ('انگلیسی مقدماتی', 'از صفر تا سطح A2 — الفبا، جمله‌سازی پایه و واژگان روزمره', 1)
on conflict do nothing;

insert into public.lessons (course_id, title, content, sort_order)
select c.id, x.title, x.content, x.ord
from public.courses c,
     (values
       ('الفبای انگلیسی', E'در این درس با حروف انگلیسی آشنا می‌شوی.\n\nA B C D E F G ... \n\nتمرین: هر حرف را بلند بخوان و صدایش را ضبط کن.'),
       ('معرفی خود', E'جمله‌های معرفی:\n- My name is ... (اسم من ... است)\n- I am from Afghanistan. (من از افغانستان هستم)\n- Nice to meet you. (از آشنایی‌تان خوشحالم)'),
       ('اعداد و شمارش', E'یک one، دو two، سه three ...\n\nتمرین: تا ۲۰ بشمار و بنویس.')
     ) as x(title, content, ord)
where c.title = 'انگلیسی مقدماتی'
  and not exists (select 1 from public.lessons l where l.title = x.title);

-- ---------- دوره ۲: مکالمه روزمره ----------
insert into public.courses (title, description, sort_order)
values ('مکالمه روزمره', 'جمله‌های کاربردی برای خرید، سفر و گفت‌وگوی روزانه', 2)
on conflict do nothing;

insert into public.lessons (course_id, title, content, sort_order)
select c.id, x.title, x.content, x.ord
from public.courses c,
     (values
       ('در بازار', E'- How much is this? (این چند است؟)\n- It is 50 afghanis. (۵۰ افغانی است)\n- Can you give me a discount? (تخفیف می‌دهی؟)'),
       ('در مسافرت', E'- Where is the bus station? (ایستگاه بس کجاست؟)\n- I need a ticket to Kabul. (بلیت کابل می‌خواهم)'),
       ('مکالمه تلفنی', E'- Hello, who is speaking? (سلام، چه کسی است؟)\n- Could you repeat that? (می‌شود تکرار کنی؟)')
     ) as x(title, content, ord)
where c.title = 'مکالمه روزمره'
  and not exists (select 1 from public.lessons l where l.title = x.title);

-- ---------- درس‌های گرامر ----------
insert into public.grammar_lessons (title, content, examples, sort_order)
select x.title, x.content, x.examples, x.ord
from (values
  ('حروف تعریف a / an / the',
   E'«a» و «an» برای اسم‌های مفرد ناشناخته به‌کار می‌روند؛ «the» برای چیز مشخص.\n- اگر کلمه با حرف صدادار (a e i o u) شروع شود از «an» استفاده کن.',
   E'a book — یک کتاب\nan apple — یک سیب\nthe sun — خورشید (چیز مشخص)', 1),
  ('زمان حال ساده',
   E'برای عادت‌ها و حقایق.\nساختار: فاعل + فعل (سوم‌شخص مفرد +s)',
   E'I play football. — من فوتبال بازی می‌کنم.\nShe plays football. — او فوتبال بازی می‌کند.', 2),
  ('زمان گذشته ساده',
   E'برای کاری که در گذشته تمام شده.\nافعال باقاعده +ed، بی‌قاعده باید حفظ شوند.',
   E'I watched a movie. — فیلم دیدم.\nHe went home. — او به خانه رفت (go → went).', 3)
) as x(title, content, examples, ord)
where not exists (select 1 from public.grammar_lessons g where g.title = x.title);

-- ---------- کوییز برای درس «معرفی خود» ----------
insert into public.quizzes (lesson_id)
select l.id from public.lessons l
where l.title = 'معرفی خود'
  and not exists (select 1 from public.quizzes q where q.lesson_id = l.id);

insert into public.quiz_questions (quiz_id, question, options, correct_index, sort_order)
select q.id, x.question, x.opts::text[], x.ci, x.ord
from public.quizzes q
join public.lessons l on l.id = q.lesson_id and l.title = 'معرفی خود',
     (values
       ('«اسم من احمد است» کدام است؟', '["My name is Ahmad.","I am 20 years old.","I am from Herat."]', 0, 1),
       ('«از آشنایی‌تان خوشحالم» کدام است؟', '["Goodbye.","Nice to meet you.","How are you?"]', 1, 2),
       ('جای خالی: I ___ from Afghanistan.', '["is","are","am"]', 2, 3)
     ) as x(question, opts, ci, ord)
where not exists (
  select 1 from public.quiz_questions qq where qq.quiz_id = q.id
);
