// ============================================================================
// Edge Function: alert-email
// رویدادهای امنیتی را به‌صورت ایمیل برای مالک می‌فرستد (via Resend)
// فراخوانی: توسط pg_cron/pg_net هر ۱۰ دقیقه با Bearer service_role
// Env لازم (با supabase secrets set یا در داشبورد):
//   RESEND_API_KEY  — کلید API از resend.com
// ============================================================================
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const EVENT_TITLES: Record<string, string> = {
  admin_auto_lock: "🔒 قفل خودکار ادمین (۵ تلاش ناموفق)",
  break_glass_used: "🚨 استفاده از کد بازیابی اضطراری",
  break_glass_failed: "⚠️ تلاش ناموفق کد بازیابی",
  role_tamper_attempt: "🚨 تلاش دستکاری نقش‌ها",
  owner_profile_delete_attempt: "🚨 تلاش حذف پروفایل مالک",
  profile_block_tamper_attempt: "🚨 تلاش تغییر وضعیت مسدودی",
  quiz_result_spoof_attempt: "⚠️ تلاش ثبت نمره برای کاربر دیگر",
  owner_created: "✅ حساب مالک ساخته شد",
};

function escapeHtml(s: unknown): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response("method not allowed", { status: 405 });
  }

  // ---------- احراز فراخواننده ----------
  const auth = req.headers.get("Authorization") ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!token) return new Response("unauthorized", { status: 401 });

  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
  const { data: secretRow } = await supabase
    .from("app_secrets")
    .select("value")
    .eq("key", "ALERT_SERVICE_KEY")
    .maybeSingle();
  const storedKey = secretRow?.value ?? "";
  if (token !== serviceKey && (storedKey === "" || token !== storedKey)) {
    return new Response("unauthorized", { status: 401 });
  }

  // ---------- گیرنده ----------
  const { data: toRow } = await supabase
    .from("app_secrets")
    .select("value")
    .eq("key", "ALERT_EMAIL_TO")
    .maybeSingle();
  const toEmail = toRow?.value;
  if (!toEmail) return new Response("ALERT_EMAIL_TO not set", { status: 400 });

  const resendKey = Deno.env.get("RESEND_API_KEY");
  if (!resendKey) return new Response("RESEND_API_KEY not set", { status: 500 });

  // ---------- بدنه ----------
  let alerts: Array<{
    id: number;
    event_type: string;
    created_at: string;
    details: unknown;
  }> = [];
  try {
    const body = await req.json();
    alerts = Array.isArray(body?.alerts) ? body.alerts : [];
  } catch {
    return new Response("bad json", { status: 400 });
  }
  if (alerts.length === 0) return new Response("no alerts", { status: 200 });

  const rows = alerts
    .map((a) => {
      const title = EVENT_TITLES[a.event_type] ?? escapeHtml(a.event_type);
      const when = new Date(a.created_at).toISOString().replace("T", " ").slice(0, 19);
      const det = escapeHtml(JSON.stringify(a.details ?? {}));
      return `<tr><td style="padding:6px 10px;border:1px solid #ddd">${title}</td><td style="padding:6px 10px;border:1px solid #ddd">${when} UTC</td><td style="padding:6px 10px;border:1px solid #ddd;direction:ltr">${det}</td></tr>`;
    })
    .join("");

  const html = `<html dir="rtl"><body style="font-family:Tahoma,Arial,sans-serif;direction:rtl">
    <h2>🔔 هشدار امنیتی زبان‌آموز</h2>
    <p>${alerts.length} رویداد امنیتی جدید ثبت شده است:</p>
    <table style="border-collapse:collapse">
      <tr><th style="padding:6px 10px;border:1px solid #ddd">رویداد</th><th style="padding:6px 10px;border:1px solid #ddd">زمان</th><th style="padding:6px 10px;border:1px solid #ddd">جزئیات</th></tr>
      ${rows}
    </table>
    <p style="color:#888">این ایمیل خودکار است — پنل ادمین زبان‌آموز</p>
  </body></html>`;

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${resendKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: "ZabanAmoz Alerts <onboarding@resend.dev>",
      to: [toEmail],
      subject: `🔔 هشدار امنیتی زبان‌آموز — ${alerts.length} رویداد`,
      html,
    }),
  });

  if (!res.ok) {
    const t = await res.text();
    return new Response(`resend error: ${t}`, { status: 502 });
  }
  return new Response(JSON.stringify({ sent: alerts.length }), {
    headers: { "Content-Type": "application/json" },
  });
});
