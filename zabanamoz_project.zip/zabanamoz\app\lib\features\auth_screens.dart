import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../core/supabase_client.dart';
import '../core/widgets.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  bool _obscure = true;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await sb.auth.signInWithPassword(
        email: _email.text.trim(),
        password: _password.text,
      );
      if (mounted) {
        // اگر پروفایل مسدود باشد، خارجش می‌کنیم
        try {
          final p = await sb.from('profiles').select('is_blocked').eq('id', sb.auth.currentUser!.id).single();
          if (p['is_blocked'] == true) {
            await sb.auth.signOut();
            AppSnackBar.show(context, 'حساب شما مسدود شده است. با پشتیبانی تماس بگیرید.', error: true);
          }
        } catch (_) {}
      }
    } on AuthException catch (e) {
      if (mounted) AppSnackBar.show(context, e.message, error: true);
    } catch (e) {
      if (mounted) AppSnackBar.show(context, 'خطا در اتصال. دوباره تلاش کنید.', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Icon(Icons.school_rounded, size: 72, color: Theme.of(context).colorScheme.primary),
                  const SizedBox(height: 8),
                  const Text('زبان‌آموز', textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text('انگلیسی را قدم‌به‌قدم یاد بگیر', textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyMedium),
                  const SizedBox(height: 32),
                  TextFormField(
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'ایمیل',
                      prefixIcon: Icon(Icons.email_outlined),
                    ),
                    validator: (v) =>
                        (v == null || !v.contains('@')) ? 'ایمیل معتبر وارد کنید' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _password,
                    obscureText: _obscure,
                    decoration: InputDecoration(
                      labelText: 'رمز عبور',
                      prefixIcon: const Icon(Icons.lock_outline),
                      suffixIcon: IconButton(
                        icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility),
                        onPressed: () => setState(() => _obscure = !_obscure),
                      ),
                    ),
                    validator: (v) =>
                        (v == null || v.length < 6) ? 'حداقل ۶ کاراکتر' : null,
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: TextButton(
                      onPressed: () => context.go('/forgot'),
                      child: const Text('فراموشی رمز عبور؟'),
                    ),
                  ),
                  const SizedBox(height: 8),
                  FilledButton(
                    onPressed: _busy ? null : _login,
                    child: _busy
                        ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Text('ورود'),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton(
                    onPressed: () => context.go('/register'),
                    child: const Text('ساخت حساب جدید'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _name = TextEditingController();
  final _password = TextEditingController();
  final _password2 = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _email.dispose();
    _name.dispose();
    _password.dispose();
    _password2.dispose();
    super.dispose();
  }

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await sb.auth.signUp(
        email: _email.text.trim(),
        password: _password.text,
        data: {'full_name': _name.text.trim()},
      );
      if (mounted) {
        await showDialog<void>(
          context: context,
          barrierDismissible: false,
          builder: (_) => AlertDialog(
            title: const Text('ثبت‌نام انجام شد'),
            content: const Text(
                'اگر ایمیل تأیید فعال باشد، لطفاً صندوق ایمیل خود را بررسی و ایمیل خود را تأیید کنید.'),
            actions: [
              FilledButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('باشه'),
              ),
            ],
          ),
        );
        if (mounted) context.go('/login');
      }
    } on AuthException catch (e) {
      if (mounted) AppSnackBar.show(context, e.message, error: true);
    } catch (e) {
      if (mounted) AppSnackBar.show(context, 'خطا در اتصال. دوباره تلاش کنید.', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ساخت حساب جدید')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _name,
                  decoration: const InputDecoration(labelText: 'نام کامل'),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'نام را وارد کنید' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: 'ایمیل'),
                  validator: (v) =>
                      (v == null || !v.contains('@')) ? 'ایمیل معتبر وارد کنید' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _password,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'رمز عبور'),
                  validator: (v) =>
                      (v == null || v.length < 6) ? 'حداقل ۶ کاراکتر' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _password2,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'تکرار رمز عبور'),
                  validator: (v) =>
                      (v != _password.text) ? 'رمزها یکسان نیستند' : null,
                ),
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: _busy ? null : _register,
                  child: _busy
                      ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Text('ثبت‌نام'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});
  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _email = TextEditingController();
  bool _busy = false;
  bool _sent = false;

  @override
  void dispose() {
    _email.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    setState(() => _busy = true);
    try {
      await sb.auth.resetPasswordForEmail(_email.text.trim());
      if (mounted) setState(() => _sent = true);
    } on AuthException catch (e) {
      if (mounted) AppSnackBar.show(context, e.message, error: true);
    } catch (e) {
      if (mounted) AppSnackBar.show(context, 'خطا در اتصال. دوباره تلاش کنید.', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('بازیابی رمز عبور')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              _sent
                  ? 'لینک بازیابی به ایمیل شما ارسال شد. لطفاً صندوق ایمیل را بررسی کنید.'
                  : 'ایمیل حساب خود را وارد کنید تا لینک بازیابی رمز عبور ارسال شود.',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            if (!_sent) ...[
              const SizedBox(height: 16),
              TextFormField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'ایمیل'),
              ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: _busy ? null : _send,
                child: const Text('ارسال لینک بازیابی'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
