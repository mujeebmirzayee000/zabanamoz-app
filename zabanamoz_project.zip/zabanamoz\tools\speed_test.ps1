Add-Type -AssemblyName System.Net.Http
$urls = @(
  @{n='flutter-google'; u='https://storage.googleapis.com/flutter_infra_release/releases/stable/windows/flutter_windows_3.24.5-stable.zip'},
  @{n='flutter-cn';     u='https://storage.flutter-io.cn/flutter_infra_release/releases/stable/windows/flutter_windows_3.24.5-stable.zip'},
  @{n='npm';            u='https://registry.npmjs.org/react/-/react-18.3.1.tgz'},
  @{n='pubdev';         u='https://pub.dev/api/packages/http'},
  @{n='github';         u='https://github.com/flutter/flutter/archive/refs/tags/3.24.5.zip'}
)
foreach ($item in $urls) {
  $client = New-Object System.Net.Http.HttpClient
  $client.Timeout = [TimeSpan]::FromSeconds(12)
  $req = New-Object System.Net.Http.HttpRequestMessage('GET', $item.u)
  $req.Headers.Range = New-Object System.Net.Http.Headers.RangeHeaderValue(0, 1048575)
  $sw = [Diagnostics.Stopwatch]::StartNew()
  try {
    $resp = $client.SendAsync($req, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).Result
    $stream = $resp.Content.ReadAsStreamAsync().Result
    $buf = New-Object byte[] 81920
    $total = 0
    while ($sw.Elapsed.TotalSeconds -lt 10) {
      $n = $stream.Read($buf, 0, $buf.Length)
      if ($n -le 0) { break }
      $total += $n
      if ($total -ge 1048576) { break }
    }
    $secs = $sw.Elapsed.TotalSeconds
    Write-Output ("{0,-16} status={1} bytes={2} secs={3:N1} KB/s={4:N1}" -f $item.n, [int]$resp.StatusCode, $total, $secs, ($total/1KB/$secs))
    $stream.Dispose()
  } catch {
    Write-Output ("{0,-16} ERROR {1}" -f $item.n, $_.Exception.Message)
  } finally {
    $client.Dispose()
    $sw.Stop()
  }
}
