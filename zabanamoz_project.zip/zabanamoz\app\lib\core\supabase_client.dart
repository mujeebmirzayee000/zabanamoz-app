import 'package:supabase_flutter/supabase_flutter.dart';

/// کلیدها از طریق --dart-define در زمان build داده می‌شوند (هیچ کلیدی در کد نیست).
class Env {
  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: '',
  );
  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: '',
  );
}

late final SupabaseClient sb;

Future<void> initSupabase() async {
  await Supabase.initialize(url: Env.supabaseUrl, anonKey: Env.supabaseAnonKey);
  sb = Supabase.instance.client;
}
