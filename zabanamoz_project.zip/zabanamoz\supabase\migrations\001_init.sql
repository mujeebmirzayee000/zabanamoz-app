-- ============================================================================
-- زبان‌آموز (ZabanAmoz) — Supabase Migration 001
-- Schema + Row Level Security + Owner Protection + Append-only Audit Log
-- اجرا: یک‌بار در Supabase SQL Editor (با نقش postgres)
-- ============================================================================

create extension if not exists pgcrypto with schema extensions;

-- ============================================================================
-- ۱) توابع کمکی امنیتی
-- ============================================================================

-- آیا کاربر فعلی Super Admin (مالک) است؟
create or replace function public.fn_is_super_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.user_roles r
    where r.user_id = auth.uid()
      and r.role = 'super_admin'
  );
$$;

-- آیا کاربر فعلی مسدود شده است؟
create or replace function public.fn_current_user_is_blocked()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce((
    select p.is_blocked
    from public.profiles p
    where p.id = auth.uid()
  ), false);
$$;

grant execute on function public.fn_is_super_admin() to anon, authenticated;
grant execute on function public.fn_current_user_is_blocked() to anon, authenticated;

-- ============================================================================
-- ۲) جدول‌ها
-- ============================================================================

-- پرچم‌های سیستمی (قفل ساخت ادمین بعد از اولین اجرا)
create table if not exists public.system_flags (
  key        text primary key,
  value      jsonb not null,
  updated_at timestamptz not null default now()
);
insert into public.system_flags(key, value) values ('owner_created', 'false'::jsonb)
  on conflict (key) do nothing;

-- پروفایل کاربران
create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  email        text not null,
  name         text,
  avatar_url   text,
  is_blocked   boolean not null default false,
  last_seen_at timestamptz,
  created_at   timestamptz not null default now()
);

-- نقش‌ها: فقط super_admin در این جدول ثبت می‌شود؛ سایر کاربران نقش ندارند = دانش‌آموز
create table if not exists public.user_roles (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  role       text not null check (role in ('super_admin')),
  created_at timestamptz not null default now()
);
-- ایندکس یونیک جزئی: در کل سیستم بیش از یک super_admin ممکن نیست (حتی با SQL مستقیم)
create unique index if not exists user_roles_one_super_admin
  on public.user_roles (role)
  where role = 'super_admin';

-- دوره‌ها
create table if not exists public.courses (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  description text,
  image_url   text,
  sort_order  integer not null default 0,
  is_published boolean not null default true,
  created_at  timestamptz not null default now()
);

-- درس‌ها
create table if not exists public.lessons (
  id          uuid primary key default gen_random_uuid(),
  course_id   uuid not null references public.courses(id) on delete cascade,
  title       text not null,
  content     text,
  video_url   text,
  sort_order  integer not null default 0,
  is_published boolean not null default true,
  created_at  timestamptz not null default now()
);
create index if not exists lessons_course_idx on public.lessons(course_id, sort_order);

-- درس‌های گرامر
create table if not exists public.grammar_lessons (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  content     text,
  examples    text,
  sort_order  integer not null default 0,
  is_published boolean not null default true,
  created_at  timestamptz not null default now()
);

-- کوییزها (هر درس حداکثر یک کوییز)
create table if not exists public.quizzes (
  id         uuid primary key default gen_random_uuid(),
  lesson_id  uuid not null unique references public.lessons(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- سوالات کوییز
create table if not exists public.quiz_questions (
  id            uuid primary key default gen_random_uuid(),
  quiz_id       uuid not null references public.quizzes(id) on delete cascade,
  question      text not null,
  options       text[] not null check (array_length(options, 1) between 2 and 6),
  correct_index integer not null check (correct_index >= 0 and correct_index < coalesce(array_length(options, 1), 0)),
  sort_order    integer not null default 0
);
create index if not exists quiz_questions_quiz_idx on public.quiz_questions(quiz_id, sort_order);

-- نتایج کوییز
create table if not exists public.quiz_results (
  id       uuid primary key default gen_random_uuid(),
  user_id  uuid not null references auth.users(id) on delete cascade,
  quiz_id  uuid not null references public.quizzes(id) on delete cascade,
  score    integer not null,
  total    integer not null,
  taken_at timestamptz not null default now()
);
create index if not exists quiz_results_user_idx on public.quiz_results(user_id, taken_at desc);
create index if not exists quiz_results_quiz_idx on public.quiz_results(quiz_id);

-- پیشرفت کاربر
create table if not exists public.user_progress (
  user_id      uuid not null references auth.users(id) on delete cascade,
  lesson_id    uuid not null references public.lessons(id) on delete cascade,
  completed_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);
create index if not exists user_progress_user_idx on public.user_progress(user_id);

-- ============================================================================
-- ۳) لاگ امنیتی Append-only با زنجیره هش (hash-chain)
-- ============================================================================

create table if not exists public.audit_log (
  id         bigint generated always as identity primary key,
  event_type text not null,
  user_id    uuid,
  ip         text,
  user_agent text,
  details    jsonb,
  prev_hash  text,
  row_hash   text not null,
  emailed    boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists audit_created_idx on public.audit_log(created_at desc);
create index if not exists audit_emailed_idx on public.audit_log(emailed) where emailed = false;

-- تلاش‌های ورود ادمین
create table if not exists public.admin_login_attempts (
  id         bigint generated always as identity primary key,
  email      text not null,
  success    boolean not null,
  ip         text,
  user_agent text,
  at         timestamptz not null default now()
);
create index if not exists admin_attempts_email_idx on public.admin_login_attempts(email, at desc);

-- قفل‌های امنیتی موقت
create table if not exists public.security_locks (
  email        text primary key,
  locked_until timestamptz not null,
  reason       text,
  unlocked_at  timestamptz,
  created_at   timestamptz not null default now()
);

-- توکن‌های یک‌بار مصرف (بازکردن قفل، بازیابی اضطراری و ...)
create table if not exists public.one_time_tokens (
  id         uuid primary key default gen_random_uuid(),
  purpose    text not null,
  token_hash text not null,
  expires_at timestamptz not null,
  used       boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists ott_purpose_idx on public.one_time_tokens(purpose, expires_at);

-- کد بازیابی اضطراری (break-glass) مالک — فقط هش ذخیره می‌شود
create table if not exists public.owner_recovery (
  user_id          uuid primary key references auth.users(id) on delete cascade,
  break_glass_hash text not null,
  used             boolean not null default false,
  created_at       timestamptz not null default now(),
  used_at          timestamptz
);

-- اسرار اپلیکیشن (فقط مالک از SQL Editor مقدار می‌دهد؛ هیچ کلاینتی دسترسی ندارد)
create table if not exists public.app_secrets (
  key        text primary key,
  value      text not null,
  updated_at timestamptz not null default now()
);

-- ============================================================================
-- ۴) ثبت رویداد در لاگ با زنجیره هش
-- ============================================================================

create or replace function public.fn_append_audit(
  p_event_type text,
  p_user_id    uuid default null,
  p_ip         text default null,
  p_user_agent text default null,
  p_details    jsonb default null
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_prev text;
  v_now  timestamptz;
  v_hash text;
begin
  -- قفل مشورتی برای جلوگیری از مسابقه در ساخت زنجیره
  perform pg_advisory_xact_lock(918273645);
  v_now := now();

  select a.row_hash into v_prev
  from public.audit_log a
  order by a.id desc
  limit 1;

  v_hash := encode(
    digest(
      coalesce(v_prev, 'GENESIS')
      || '|' || p_event_type
      || '|' || coalesce(p_user_id::text, '')
      || '|' || coalesce(p_ip, '')
      || '|' || coalesce(p_user_agent, '')
      || '|' || coalesce(p_details::text, '')
      || '|' || extract(epoch from v_now)::text,
      'sha256'
    ),
    'hex'
  );

  insert into public.audit_log
    (event_type, user_id, ip, user_agent, details, prev_hash, row_hash, created_at)
  values
    (p_event_type, p_user_id, p_ip, p_user_agent, p_details, v_prev, v_hash, v_now);
end;
$$;

-- هیچ کلاینتی حق فراخوانی مستقیم این تابع را ندارد
revoke execute on function public.fn_append_audit(text, uuid, text, text, jsonb) from public, anon, authenticated;

-- ============================================================================
-- ۵) استخراج IP و User-Agent از هدرهای درخواست
-- ============================================================================

create or replace function public.fn_request_meta()
returns jsonb
language plpgsql
stable
set search_path = ''
as $$
declare
  v_h jsonb;
begin
  begin
    v_h := nullif(current_setting('request.headers', true), '')::jsonb;
  exception when others then
    v_h := null;
  end;
  return jsonb_build_object(
    'ip', coalesce(v_h ->> 'x-forwarded-for', v_h ->> 'cf-connecting-ip'),
    'ua', v_h ->> 'user-agent'
  );
end;
$$;

-- ============================================================================
-- ۶) نگهبان‌های (Triggers) محافظت از مالک
-- ============================================================================

-- ۶.۱) هیچ کاربر وارد‌شده‌ای نمی‌تواند جدول نقش‌ها را تغییر دهد
create or replace function public.fn_guard_user_roles()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_meta jsonb;
  v_uid  uuid;
begin
  v_meta := public.fn_request_meta();
  v_uid  := auth.uid();
  if v_uid is null then
    begin
      v_uid := (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')::uuid;
    exception when others then
      v_uid := null;
    end;
  end if;

  if v_uid is not null then
    perform public.fn_append_audit(
      'role_tamper_attempt', v_uid,
      v_meta ->> 'ip', v_meta ->> 'ua',
      jsonb_build_object('op', TG_OP, 'table', TG_TABLE_NAME,
                         'old', to_jsonb(OLD), 'new', to_jsonb(NEW))
    );
    raise exception 'DENIED: مدیریت نقش‌ها قفل است. تغییر نقش فقط از طریق اسکریپت محافظت‌شده مالک ممکن است.';
  end if;

  if TG_OP = 'DELETE' then
    return OLD;
  end if;
  return NEW;
end;
$$;

create trigger trg_guard_user_roles_insert
  before insert on public.user_roles
  for each row execute function public.fn_guard_user_roles();

create trigger trg_guard_user_roles_update
  before update on public.user_roles
  for each row execute function public.fn_guard_user_roles();

create trigger trg_guard_user_roles_delete
  before delete on public.user_roles
  for each row execute function public.fn_guard_user_roles();

-- ۶.۲) محافظت از پروفایل مالک و وضعیت مسدودی
create or replace function public.fn_guard_profiles()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_meta jsonb;
begin
  v_meta := public.fn_request_meta();

  if TG_OP = 'DELETE' then
    if exists (
      select 1 from public.user_roles r
      where r.user_id = OLD.id and r.role = 'super_admin'
    ) then
      perform public.fn_append_audit(
        'owner_profile_delete_attempt', auth.uid(),
        v_meta ->> 'ip', v_meta ->> 'ua',
        jsonb_build_object('target', OLD.id)
      );
      raise exception 'DENIED: پروفایل مالک قابل حذف نیست.';
    end if;
    return OLD;
  end if;

  -- UPDATE: تغییر وضعیت مسدودی فقط توسط مالک
  if not public.fn_is_super_admin()
     and coalesce(NEW.is_blocked, false) <> coalesce(OLD.is_blocked, false) then
    perform public.fn_append_audit(
      'profile_block_tamper_attempt', auth.uid(),
      v_meta ->> 'ip', v_meta ->> 'ua',
      jsonb_build_object('target', NEW.id, 'old_blocked', OLD.is_blocked, 'new_blocked', NEW.is_blocked)
    );
    raise exception 'DENIED: تغییر وضعیت مسدودی فقط توسط مالک ممکن است.';
  end if;

  return NEW;
end;
$$;

create trigger trg_guard_profiles
  before update or delete on public.profiles
  for each row execute function public.fn_guard_profiles();

-- ۶.۳) ساخت خودکار پروفایل بعد از ثبت‌نام (بدون هیچ نقشی)
create or replace function public.fn_on_auth_user_created()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, name)
  values (
    NEW.id,
    NEW.email,
    coalesce(NEW.raw_user_meta_data ->> 'name', null)
  )
  on conflict (id) do nothing;
  return NEW;
end;
$$;

create trigger trg_on_auth_user_created
  after insert on auth.users
  for each row execute function public.fn_on_auth_user_created();

-- ۶.۴) جلوگیری از ثبت/تغییر نمره‌های کوییز توسط افراد دیگر
create or replace function public.fn_guard_quiz_results()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if TG_OP = 'DELETE' then
    if exists (
      select 1 from public.user_roles r
      where r.user_id = OLD.user_id and r.role = 'super_admin'
    ) then
      raise exception 'DENIED: رکوردهای مالک محافظت شده‌اند.';
    end if;
    return OLD;
  end if;

  if NEW.user_id <> auth.uid() then
    perform public.fn_append_audit(
      'quiz_result_spoof_attempt', auth.uid(), null, null,
      jsonb_build_object('claimed_user', NEW.user_id)
    );
    raise exception 'DENIED: فقط نتیجه خودتان قابل ثبت است.';
  end if;
  return NEW;
end;
$$;

create trigger trg_guard_quiz_results
  before insert or delete on public.quiz_results
  for each row execute function public.fn_guard_quiz_results();

-- ============================================================================
-- ۷) فعال‌سازی RLS روی همه جدول‌ها
-- ============================================================================

alter table public.system_flags          enable row level security;
alter table public.profiles              enable row level security;
alter table public.user_roles            enable row level security;
alter table public.courses               enable row level security;
alter table public.lessons               enable row level security;
alter table public.grammar_lessons       enable row level security;
alter table public.quizzes               enable row level security;
alter table public.quiz_questions        enable row level security;
alter table public.quiz_results          enable row level security;
alter table public.user_progress         enable row level security;
alter table public.audit_log             enable row level security;
alter table public.admin_login_attempts  enable row level security;
alter table public.security_locks        enable row level security;
alter table public.one_time_tokens       enable row level security;
alter table public.owner_recovery        enable row level security;
alter table public.app_secrets           enable row level security;

-- ============================================================================
-- ۸) سیاست‌های RLS
-- ============================================================================

-- ---------- profiles ----------
create policy "profiles_select_own_or_admin" on public.profiles
  for select using (id = auth.uid() or public.fn_is_super_admin());

create policy "profiles_insert_own" on public.profiles
  for insert with check (id = auth.uid());

create policy "profiles_update_own_or_admin" on public.profiles
  for update
  using (id = auth.uid() or public.fn_is_super_admin())
  with check (id = auth.uid() or public.fn_is_super_admin());
-- هیچ سیاست DELETE وجود ندارد → حذف برای همه کلاینت‌ها مسدود است

-- ---------- user_roles ----------
-- خواندن: فقط مالک
create policy "user_roles_select_admin" on public.user_roles
  for select to authenticated using (public.fn_is_super_admin());

-- دروازه‌های تله: با check(false) + تریگر نگهبان = تلاش ثبت می‌شود و رد می‌شود
create policy "user_roles_no_insert" on public.user_roles
  for insert to anon, authenticated with check (false);

create policy "user_roles_update_gate" on public.user_roles
  for update to authenticated using (true) with check (false);

create policy "user_roles_delete_gate" on public.user_roles
  for delete to authenticated using (true);
-- delete به anon داده نشده؛ برای authenticated تریگر نگهبان رد می‌کند

-- ---------- محتوای آموزشی (فقط مالک می‌نویسد) ----------
create policy "courses_read" on public.courses
  for select using (
    not public.fn_current_user_is_blocked()
    and (is_published or public.fn_is_super_admin())
  );
create policy "courses_insert_admin" on public.courses
  for insert with check (public.fn_is_super_admin());
create policy "courses_update_admin" on public.courses
  for update using (public.fn_is_super_admin()) with check (public.fn_is_super_admin());
create policy "courses_delete_admin" on public.courses
  for delete using (public.fn_is_super_admin());

create policy "lessons_read" on public.lessons
  for select using (
    not public.fn_current_user_is_blocked()
    and (is_published or public.fn_is_super_admin())
  );
create policy "lessons_insert_admin" on public.lessons
  for insert with check (public.fn_is_super_admin());
create policy "lessons_update_admin" on public.lessons
  for update using (public.fn_is_super_admin()) with check (public.fn_is_super_admin());
create policy "lessons_delete_admin" on public.lessons
  for delete using (public.fn_is_super_admin());

create policy "grammar_read" on public.grammar_lessons
  for select using (
    not public.fn_current_user_is_blocked()
    and (is_published or public.fn_is_super_admin())
  );
create policy "grammar_insert_admin" on public.grammar_lessons
  for insert with check (public.fn_is_super_admin());
create policy "grammar_update_admin" on public.grammar_lessons
  for update using (public.fn_is_super_admin()) with check (public.fn_is_super_admin());
create policy "grammar_delete_admin" on public.grammar_lessons
  for delete using (public.fn_is_super_admin());

create policy "quizzes_read" on public.quizzes
  for select using (public.fn_is_super_admin() or exists (
    select 1 from public.lessons l
    where l.id = quizzes.lesson_id and l.is_published
  ));
create policy "quizzes_insert_admin" on public.quizzes
  for insert with check (public.fn_is_super_admin());
create policy "quizzes_update_admin" on public.quizzes
  for update using (public.fn_is_super_admin()) with check (public.fn_is_super_admin());
create policy "quizzes_delete_admin" on public.quizzes
  for delete using (public.fn_is_super_admin());

create policy "quiz_questions_read" on public.quiz_questions
  for select using (public.fn_is_super_admin() or exists (
    select 1
    from public.quizzes q
    join public.lessons l on l.id = q.lesson_id
    where q.id = quiz_questions.quiz_id and l.is_published
  ));
create policy "quiz_questions_insert_admin" on public.quiz_questions
  for insert with check (public.fn_is_super_admin());
create policy "quiz_questions_update_admin" on public.quiz_questions
  for update using (public.fn_is_super_admin()) with check (public.fn_is_super_admin());
create policy "quiz_questions_delete_admin" on public.quiz_questions
  for delete using (public.fn_is_super_admin());

-- ---------- نتایج کوییز ----------
create policy "quiz_results_insert_own" on public.quiz_results
  for insert to authenticated with check (user_id = auth.uid());

create policy "quiz_results_select_own_or_admin" on public.quiz_results
  for select using (user_id = auth.uid() or public.fn_is_super_admin());
-- هیچ update/delete → نمره‌ها تغییرناپذیرند

-- ---------- پیشرفت کاربر ----------
create policy "progress_insert_own" on public.user_progress
  for insert to authenticated with check (user_id = auth.uid());

create policy "progress_select_own" on public.user_progress
  for select to authenticated using (user_id = auth.uid());

create policy "progress_update_own" on public.user_progress
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "progress_delete_own" on public.user_progress
  for delete to authenticated using (user_id = auth.uid());

-- ---------- audit_log: append-only ----------
create policy "audit_insert_service" on public.audit_log
  for insert to postgres, service_role with check (true);

create policy "audit_select_admin" on public.audit_log
  for select to authenticated using (public.fn_is_super_admin());

-- علامت‌گذاری «ایمیل شد» فقط توسط سرویس داخلی
create policy "audit_mark_emailed_service" on public.audit_log
  for update to postgres, service_role using (true) with check (true);
-- هیچ update/delete برای anon/authenticated → append-only تضمین می‌شود

-- ---------- admin_login_attempts ----------
create policy "attempts_insert_service" on public.admin_login_attempts
  for insert to postgres, service_role with check (true);

create policy "attempts_select_admin" on public.admin_login_attempts
  for select to authenticated using (public.fn_is_super_admin());

-- ---------- security_locks ----------
create policy "locks_service_write" on public.security_locks
  for all to postgres, service_role using (true) with check (true);

create policy "locks_select_admin" on public.security_locks
  for select to authenticated using (public.fn_is_super_admin());

-- ---------- one_time_tokens / owner_recovery / app_secrets ----------
-- هیچ سیاستی برای کلاینت‌ها وجود ندارد → کامل مسدود
create policy "ott_service" on public.one_time_tokens
  for all to postgres, service_role using (true) with check (true);

create policy "owner_recovery_service" on public.owner_recovery
  for all to postgres, service_role using (true) with check (true);

create policy "app_secrets_service" on public.app_secrets
  for all to postgres, service_role using (true) with check (true);

create policy "system_flags_service" on public.system_flags
  for all to postgres, service_role using (true) with check (true);

-- ============================================================================
-- ۹) توابع عملیاتی امنیتی (فقط service_role / postgres)
-- ============================================================================

-- ثبت تلاش ورود ادمین + قفل خودکار بعد از ۵ تلاش ناموفق در ۱۰ دقیقه
create or replace function public.fn_record_admin_attempt(
  p_email  text,
  p_success boolean,
  p_ip     text default null,
  p_ua     text default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_email text;
  v_fail  integer;
  v_uid   uuid;
  v_locked boolean := false;
begin
  v_email := lower(btrim(coalesce(p_email, '')));
  if v_email = '' then
    raise exception 'email required';
  end if;

  insert into public.admin_login_attempts (email, success, ip, user_agent)
  values (v_email, p_success, p_ip, p_ua);

  perform public.fn_append_audit(
    case when p_success then 'admin_login_success' else 'admin_login_failed' end,
    null, p_ip, p_ua,
    jsonb_build_object('email', v_email)
  );

  if not p_success then
    select count(*) into v_fail
    from public.admin_login_attempts
    where email = v_email
      and success = false
      and at > now() - interval '10 minutes';

    if v_fail >= 5 then
      insert into public.security_locks (email, locked_until, reason)
      values (v_email, now() + interval '30 minutes', '۵ تلاش ناموفق در ۱۰ دقیقه')
      on conflict (email) do update
        set locked_until = now() + interval '30 minutes',
            reason = excluded.reason,
            unlocked_at = null;

      -- باطل کردن همه سیشن‌های فعال آن اکانت
      select id into v_uid from auth.users where lower(email) = v_email;
      if v_uid is not null then
        delete from auth.sessions where user_id = v_uid;
        delete from auth.refresh_tokens where user_id = v_uid;
      end if;

      perform public.fn_append_audit(
        'admin_auto_lock', v_uid, p_ip, p_ua,
        jsonb_build_object('email', v_email, 'failures', v_fail)
      );
      v_locked := true;
    end if;
  end if;

  return jsonb_build_object('locked', v_locked);
end;
$$;

revoke execute on function public.fn_record_admin_attempt(text, boolean, text, text) from public, anon, authenticated;

-- وضعیت قفل یک ایمیل
create or replace function public.fn_get_admin_lock(p_email text)
returns timestamptz
language sql
stable
security definer
set search_path = ''
as $$
  select l.locked_until
  from public.security_locks l
  where l.email = lower(btrim(coalesce(p_email, '')))
    and l.locked_until > now();
$$;

revoke execute on function public.fn_get_admin_lock(text) from public, anon, authenticated;

-- بررسی و مصرف کد break-glass (فقط از طریق تابع لبه با service key)
create or replace function public.fn_verify_break_glass(p_email text, p_code text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid  uuid;
  v_hash text;
  v_used boolean;
begin
  select u.id into v_uid
  from auth.users u
  where lower(u.email) = lower(btrim(coalesce(p_email, '')));

  if v_uid is null then
    return null;
  end if;

  select r.break_glass_hash, r.used into v_hash, v_used
  from public.owner_recovery r
  where r.user_id = v_uid;

  if v_used or v_hash is null then
    return null;
  end if;

  if extensions.crypt(p_code, v_hash) = v_hash then
    update public.owner_recovery
    set used = true, used_at = now()
    where user_id = v_uid;
    perform public.fn_append_audit('break_glass_used', v_uid, null, null, '{}'::jsonb);
    return v_uid;
  end if;

  perform public.fn_append_audit('break_glass_failed', v_uid, null, null, '{}'::jsonb);
  return null;
end;
$$;

revoke execute on function public.fn_verify_break_glass(text, text) from public, anon, authenticated;

-- ============================================================================
-- ۱۰) ویو ویدیوها برای اپ کاربر
-- ============================================================================

create or replace view public.lesson_videos
with (security_invoker = true) as
select
  l.id,
  l.title,
  l.video_url,
  c.title as course_title,
  c.id    as course_id
from public.lessons l
join public.courses c on c.id = l.course_id
where l.video_url is not null
  and l.is_published
  and c.is_published;

grant select on public.lesson_videos to anon, authenticated;

-- ============================================================================
-- ۱۱) باکت‌های Storage و سیاست‌ها
-- ============================================================================

insert into storage.buckets (id, name, public)
values ('media', 'media', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

-- باکت media: خواندن عمومی، نوشتن فقط مالک
create policy "media_public_read" on storage.objects
  for select using (bucket_id = 'media');

create policy "media_admin_insert" on storage.objects
  for insert with check (bucket_id = 'media' and public.fn_is_super_admin());

create policy "media_admin_update" on storage.objects
  for update
  using (bucket_id = 'media' and public.fn_is_super_admin())
  with check (bucket_id = 'media' and public.fn_is_super_admin());

create policy "media_admin_delete" on storage.objects
  for delete using (bucket_id = 'media' and public.fn_is_super_admin());

-- باکت avatars: خواندن عمومی، نوشتن فقط پوشه خود کاربر یا مالک
create policy "avatars_public_read" on storage.objects
  for select using (bucket_id = 'avatars');

create policy "avatars_owner_insert" on storage.objects
  for insert with check (
    bucket_id = 'avatars'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.fn_is_super_admin())
  );

create policy "avatars_owner_update" on storage.objects
  for update
  using (
    bucket_id = 'avatars'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.fn_is_super_admin())
  )
  with check (
    bucket_id = 'avatars'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.fn_is_super_admin())
  );

create policy "avatars_owner_delete" on storage.objects
  for delete using (
    bucket_id = 'avatars'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.fn_is_super_admin())
  );

-- ============================================================================
-- پایان Migration 001
-- ============================================================================
